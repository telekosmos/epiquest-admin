package org.cnio.appform.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * PatGivesAnswer2ques entity.
 * 
 * @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "pat_gives_answer2ques", schema = "public", uniqueConstraints = {})
public class PatGivesAnswer2ques implements java.io.Serializable {

	// Fields

	private Integer idpAQ;
	private Question question;
	private Answer answer;
	private Patient patient;
	private Integer answerNumber;
	private Integer answerOrder;

	// Constructors

	/** default constructor */
	public PatGivesAnswer2ques() {
	}

	/** minimal constructor */
	public PatGivesAnswer2ques(Integer idpAQ) {
		this.idpAQ = idpAQ;
	}

	/** full constructor */
	public PatGivesAnswer2ques(Integer idpAQ, Question question, Answer answer,
	    Patient patient, Integer answerNumber, Integer answerOrder) {
		this.idpAQ = idpAQ;
		this.question = question;
		this.answer = answer;
		this.patient = patient;
		this.answerNumber = answerNumber;
		this.answerOrder = answerOrder;
	}

	// Property accessors
	@Id
	@Column(name = "idp_a_q", unique = true, nullable = false, insertable = true, updatable = true)
	public Integer getIdpAQ() {
		return this.idpAQ;
	}

	public void setIdpAQ(Integer idpAQ) {
		this.idpAQ = idpAQ;
	}

	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "codquestion", unique = false, nullable = true, insertable = true, updatable = true)
	public Question getQuestion() {
		return this.question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "codanswer", unique = false, nullable = true, insertable = true, updatable = true)
	public Answer getAnswer() {
		return this.answer;
	}

	public void setAnswer(Answer answer) {
		this.answer = answer;
	}

	@ManyToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "codpat", unique = false, nullable = true, insertable = true, updatable = true)
	public Patient getPatient() {
		return this.patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	@Column(name = "answer_number", unique = false, nullable = true, insertable = true, updatable = true)
	public Integer getAnswerNumber() {
		return this.answerNumber;
	}

	public void setAnswerNumber(Integer answerNumber) {
		this.answerNumber = answerNumber;
	}

	@Column(name = "answer_order", unique = false, nullable = true, insertable = true, updatable = true)
	public Integer getAnswerOrder() {
		return this.answerOrder;
	}

	public void setAnswerOrder(Integer answerOrder) {
		this.answerOrder = answerOrder;
	}

}