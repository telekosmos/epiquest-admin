package org.cnio.appform.entity;

import java.util.List;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.SequenceGenerator;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.SEQUENCE;
import javax.persistence.OneToMany;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import static javax.persistence.CascadeType.ALL;
import javax.persistence.Table;

@Entity
@Table(name="interview")
public class Interview implements java.io.Serializable, Cloneable {
	@Id
	@Column(name="idinterview")
	@SequenceGenerator(name="SecGenerator", sequenceName = "interview_idinterview_seq")
	@GeneratedValue(strategy=SEQUENCE, generator = "SecGenerator")
	private Integer id;
	@Column(name="name")
	private String name;
	@Column(name="description")
	private String description;

// parent-child relationship just to gather interviews which actually will be
// the same interviews with different languages and/or cultures
// source is actually the interview parent of this interview, null if no parent	
	@ManyToOne(targetEntity=Interview.class)
	@JoinColumn(name="source") // this actually is the foreign key columng
	protected Interview sourceIntrv;
		
// children are the interviews which this interview is the parent for 
	@OneToMany(mappedBy="sourceIntrv", cascade={CascadeType.MERGE, CascadeType.PERSIST})
	protected List<Interview> children;
	
// the types for the answerItems related to this interview
	@OneToMany(mappedBy="intrvOwner", cascade = ALL)
	private List<AnswerItem> answerItems;	
	
// one interview has more sections	
	@OneToMany(mappedBy="parentInt", cascade = ALL)
	private List<Section> sections;
	
/* another oneTomany for interview instances...
	@OneToMany(mappedBy="theInterview", cascade = ALL)
	private List<IntrvInstance> instances;
*/	
// many interviews belong to a project	
	@ManyToOne(targetEntity=Project.class)
	@JoinColumn(name="codprj")
	private Project parentPrj;
	
//many interviews belong to a user	
	@ManyToOne(targetEntity=AppUser.class, cascade={CascadeType.REFRESH})
	@JoinColumn(name="codusr")
	private AppUser usrOwner;
	
//One interview can be done several times for several patients: ternary rel
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "interview")
	private Collection<Performance> performances;	
	
	
// One interview CAN have several groups (ACTUALLY this is not true and the
// relationship is built up as M:N for futures developments or requierements 
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "intrv")
	private List<RelIntrvGroup> relIntrvGrps;	
	
	
	public Interview () {
		sections = new ArrayList<Section>();
		performances = new ArrayList<Performance>();
		
		relIntrvGrps = new ArrayList<RelIntrvGroup> ();
		children = new ArrayList<Interview>();
		answerItems = new ArrayList<AnswerItem>();
	}

	
	public Interview (String name, String description) {
		this ();
		
		this.name = name;
		this.description = description;
	}

	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
	public List<Section> getSections() {
		return sections;
	}

	public void setSections(List<Section> sections) {
		this.sections = sections;
	}
	
	public void setProject (Project prj) {
		this.parentPrj = prj;
		
		prj.getInterviews().add(this);
		
	}
	
	public Project getParentProj () {
		return parentPrj;
	}

/*	
	public List<IntrvInstance> getInstances() {
		return instances;
	}

	public void setInstances(List<IntrvInstance> instances) {
		this.instances = instances;
	}
*
	public Project getParentPrj() {
		return parentPrj;
	}
*/
	public void setParentPrj(Project parentPrj) {
		this.parentPrj = parentPrj;
		
		parentPrj.getInterviews().add(this);
	}
	
	
	public AppUser getUsrOwner() {
		return usrOwner;
	}

	public void setUsrOwner (AppUser owner) {
		this.usrOwner = owner;
	
		usrOwner.getInterviews().add(this);
	}

	public Collection<Performance> getPerformances() {
		return performances;
	}

	public void setPerformances(Collection<Performance> performances) {
		this.performances = performances;
	}

	public List<RelIntrvGroup> getRelIntrvGrps() {
		return relIntrvGrps;
	}

	public void setRelIntrvGrps(List<RelIntrvGroup> relIntrvGrps) {
		this.relIntrvGrps = relIntrvGrps;
	}
	
	
	public Object clone () throws CloneNotSupportedException {
		Interview intrv = new Interview (this.name, this.description);
//		Interview intrv = (Interview)super.clone();

// set the types for the cloned interview
		for (Iterator<AnswerItem> itAi = answerItems.iterator(); itAi.hasNext();) {
			AnswerItem ai = itAi.next();
			AnswerItem newAi;
			
			if (ai instanceof AnswerType)
				newAi = (AnswerItem)((AnswerType)ai).clone();
			else
				newAi = (AnswerItem)((EnumType)ai).clone();
			
			newAi.setIntrvOwner(intrv);
		}
		
// set the section for the cloned interview		
		for (Iterator<Section> iter = sections.iterator(); iter.hasNext(); ) {
			Section src = iter.next();
			Section aux = (Section)src.clone();
System.out.print("=");			
			aux.setInterview(intrv);
		}

		intrv.setParentPrj(this.getParentProj());
		intrv.setId(null);
		intrv.setPerformances(null);
		intrv.setSourceIntrv(this);
// the new group has to be set		
//		intrv.setRelIntrvGrps(relIntrvGrps);
		
		return intrv;
	}


	public Interview getSourceIntrv() {
		return sourceIntrv;
	}


	public void setSourceIntrv(Interview source) {
		this.sourceIntrv = source;
		
		if (source != null) {
			this.sourceIntrv = source;
			source.getChildren().add(this);
		}
		else {
			this.sourceIntrv.getChildren().remove(this);
			this.sourceIntrv = null;
		}
	}


	public List<Interview> getChildren() {
		return children;
	}


	public void setChildren(List<Interview> children) {
		this.children = children;
	}
	
	public void removeChildren () {
		this.children.clear();
	}


	public List<AnswerItem> getAnswerItems() {
		return answerItems;
	}


	public void setAnswerItems(List<AnswerItem> answerItems) {
		this.answerItems = answerItems;
	}
	
	public void setAnswerItem (AnswerItem ai) {
		if (ai != null) {
			this.answerItems.add(ai);
			ai.setIntrvOwner(this);
		}
		
	}
	
}
