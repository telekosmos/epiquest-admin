package org.cnio.appform.jaas;
/* Java imports */
import java.util.Properties;

/**
 * <p>
 * RdbmsCredential extends Properties in order to supply
 * a location for credential data which might be retrieved
 * from the database.
 *
 * @author  Paul Feuer and John Musser
 * @version 1.0
 */

public class AppCredential extends Properties {

    public AppCredential() {
    }
}

