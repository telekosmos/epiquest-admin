package org.cnio.appform.audit;

import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.text.DateFormat;

import javax.servlet.*;
import javax.servlet.http.*;

import org.hibernate.Session;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import org.hibernate.Query;

import org.cnio.appform.entity.AppUser;
import org.cnio.appform.entity.AppGroup;
import org.cnio.appform.entity.RelGrpAppuser;
import org.cnio.appform.entity.AppDBLogger;
import org.cnio.appform.util.LogFile;
import org.cnio.appform.util.HibernateUtil;
import org.cnio.appform.util.AppUserCtrl;


public class AppSessionListener implements HttpSessionListener {

	private int sessionCount;
	private Session hibSes;
	
	public AppSessionListener() {
		this.sessionCount = 0;
		hibSes = HibernateUtil.getSessionFactory().openSession();
	}
	

/**
 * This method is call back by the container when one session is created. 
 * Actually, it does nothing as the session creation logging is done in
 * jsp/index.jsp
 */
	public void sessionCreated(HttpSessionEvent se) {

		HttpSession session = se.getSession();

		// increment the session count
		sessionCount++;

		String sessionid = session.getId();
System.out.println("AppSessionListener - sessionId: "+sessionid);
System.out.println("AppSessionListener - sessoin attrs: ");
		for (Enumeration en=session.getAttributeNames(); en.hasMoreElements();) {
			String item = (String)en.nextElement();
			System.out.print(item+",");
		}
		System.out.println();
		
		Date now = new Date();
	}
	

/**
 * This is the method called back by the container when one session is
 * invalidated/destroyed. 
 * In order to implement the logging for the application, a row with the same
 * sessionid has to be retrieved to get the username, then one row is inserted
 * in the applog table and the user row has to be updated to set the loggedin
 * field to 0
 */
	public void sessionDestroyed(HttpSessionEvent se) {
		HttpSession session = se.getSession();
		String id = session.getId(), msgLog = "", username = "";
		String hql = "from AppDBLogger where sessionId='"+id+"' order by evTime desc";
		List<AppDBLogger> logRows = null;
		
		Integer logged = (Integer)session.getAttribute("logged");
		Integer usrId = (Integer)session.getAttribute("usrid");
		AppUser theUser = (AppUser)hibSes.get(AppUser.class, usrId);
		
		if (logged == null)
			return;
		
		Transaction tx = null;
		try {
			if (!hibSes.isOpen())
				hibSes = HibernateUtil.getSessionFactory().openSession();
			
			tx = hibSes.beginTransaction();
			Query qry = hibSes.createQuery(hql);
			logRows = qry.list();
			
			if (logRows != null && logRows.size() > 0) {
// set the user loggedin to 0 and loggedfrom to null				
				username = theUser.getUsername();
				theUser.setLoggedIn(0);
				theUser.setLoggedFrom(null);

// msg = "User "+theUser.getUsername()+" has logged in attribute set to"+
//theUser.getLoggedIn();
//LogFile.info(msg);
// This is performed by a trigger	
				AppDBLogger endSesLog = new AppDBLogger ();
				msgLog = "User '"+theUser.getUsername()+"' has finished the session";
				endSesLog.setMessage(msgLog);
				endSesLog.setUserId(usrId);
				endSesLog.setSessionId(id);
				
				hibSes.save(endSesLog);
			}
			else {
				LogFile.error("No previous data found for this session ("+
							id+") in database log");
			}
			
// set all groups belonging this user to active=0
			AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
			AppGroup primary = usrCtrl.getPrimaryActiveGroup(theUser),
							secondary = usrCtrl.getSecondaryActiveGroup(theUser);

			String hqlQry = "from RelGrpAppuser r where r.appuser=:user and (" +
					"r.appgroup=:primary", hqlQryBis =" or r.appgroup=:secondary)";
			

			if (primary != null || secondary != null) {
			
				if (secondary == null) {
					qry = hibSes.createQuery(hqlQry+")");
					qry.setEntity("user", theUser);
					qry.setEntity("primary", primary);
				}
				else {
					qry = hibSes.createQuery(hqlQry+hqlQryBis);
					qry.setEntity("user", theUser);
					qry.setEntity("primary", primary);
					qry.setEntity("secondary", secondary);
				}
				
// set to 0 all possible active groups, not only the current active one(s)
				List<RelGrpAppuser> rels = qry.list();
System.out.println ("Deactivating "+rels.size()+" groups for user "
		+theUser.getUsername());
				for (Iterator<RelGrpAppuser> it=rels.iterator(); it.hasNext();) {
					RelGrpAppuser rel = it.next();
System.out.println ("Deactive group "+rel.getAppgroup().getId());
					rel.setActive(0);
				}
			}
			
			msgLog = "SessionListener: User '"+username+"'("+usrId+") has logged out";
			LogFile.info(msgLog);
			tx.commit();
			
// log to file as well
		}
		catch (HibernateException hibEx) {
			if (tx != null) {
				tx.rollback();
				hibSes.close();
			}
hibEx.printStackTrace();			
			String msg = "Unable to finish and record logging out for session "+id;
			StackTraceElement[] stack = hibEx.getStackTrace();
			LogFile.error(msg);
			LogFile.error(hibEx.getLocalizedMessage());
			LogFile.logStackTrace(stack);
		}
		catch (Exception ex) {
			if (tx != null) {
				tx.rollback();
				hibSes.close();
			}
ex.printStackTrace();			
			String msg = "Unable to finish and record logging out for session "+id;
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.error(msg);
			LogFile.error(ex.getLocalizedMessage());
			LogFile.logStackTrace(stack);
		}
		
		--sessionCount;// decrement the session count variable
	}
}