package org.cnio.appform.util;

import static org.hibernate.criterion.Restrictions.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.AnnotatedClassType;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.*;
import org.hibernate.SQLQuery;

import org.cnio.appform.entity.*;
import org.cnio.appform.audit.ActionsLogger;

/**
 * This class contains methods to control the user properties
 * @author willy
 *
 */
public class IntrvFormCtrl {

	private Session hibSes;
	
	private String errMsg;
	
// This is the patient code used for previewing
	public static final String NULL_PATIENT = "00000000";
	
// This is the patient code used for testing, it won't be included on queries
	public static final String TEST_PATIENT = "69696969";
	
	public IntrvFormCtrl (Session aSession) {
		hibSes = aSession;
		errMsg = "";
	}


	
/**
 * Create a new performance
 * Inserts a new row in the performance table for the new patient who is gonna
 * be interviewed by one user (it means, belonging to a GROUP).
 * A performance has to be saved when:
 * - the user can access the patient => the patient is new 
 * OR 
 * - the patient is NULL_PATIENT and the performance is new for this user's group
 * 
 * It doesent have to be saved when:
 * - is used in a performance by one of the user's partners (himself included)
 * 
 * @param userId, the user id, who is gonna perform the interview
 * @param intrvId, the interview id
 * @param patCode, the patient code which is gonna be saved. it will be the
 * patient identifier
 * @return
 */	
	public Performance savePerformance (Integer userId, String sessId, 
																	String lastIp, Integer intrvId, 
																	String patCode, String place) {
		Transaction tx = null;
		
		Patient patient = this.getPatientFromCode(patCode);
		Performance perf;
		boolean patientAllowed;
		ActionsLogger logDb = new ActionsLogger (hibSes);
		
		try {
//			tx = hibSes.beginTransaction();
			Interview intrv = (Interview)hibSes.get(Interview.class, intrvId);
			AppUser usr = (AppUser)hibSes.get(AppUser.class, userId);
//			tx.commit();
			
			if (patient != null) { // patient exists
// we have to see if the patient belongs to this user's group
				patientAllowed = this.isPatientCodeAllowed(patient, userId);
				if (!patientAllowed) {
					errMsg = "Duplicate patient ("+patient.getCodpatient()+")";
					errMsg += ". Please choose another code for the patient";
					
					logDb.customLog(sessId, lastIp, userId, patCode, errMsg);
					return null;
				} 
				else { // we gotta see whether or not this patient has a performance with
							// the interview represented by intrvId
					perf = this.getPerformance(patCode, intrvId, userId, sessId, lastIp);
					if (perf != null) {
//						tx.commit();
						return perf;
					}
				}  // patient exists and it is allowed
				
			}
			else { // patient is null, so we can create it and process it
				tx = hibSes.beginTransaction();
				patient =	new Patient (patCode);
				Integer patId = (Integer)hibSes.save(patient);
				tx.commit();
				
				logDb.logItem(sessId, lastIp, userId, ActionsLogger.PATIENT, patId, 
										patCode, ActionsLogger.CREATE);
				
				String msgLog = "New patient created with code: '"+patCode+"'";
				LogFile.info (msgLog);
			}
			AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
			AppGroup secondaryGrp = usrCtrl.getSecondaryGroup(usr);
			
			if (tx == null)
				tx = hibSes.beginTransaction();
			else
				tx.begin();
			
			if (usr == null || intrv == null || 
					patient == null || secondaryGrp == null) {
				errMsg = "The requested interview performance could not be recorded.\\n";
				errMsg += "Either the group the user belongs to " +
						"or the patient code is invalid.\\n";
				errMsg += "Please, contact and report to administrator";
				
				LogFile.getLogger().error(errMsg);
				
				tx.rollback();
				return null;
			}
			else {
				perf = new Performance (usr, intrv, patient, secondaryGrp);
				perf.setPlace(place);
				perf.setLastSec(new Integer (1));
				Integer perfId = (Integer)hibSes.save(perf);
				
				tx.commit();
				
				logDb.logItem(sessId, lastIp, userId, 
										ActionsLogger.PERFORMANCE, perfId, intrv.getName(), ActionsLogger.CREATE);
				
				String logMsg = "New performance saved for user: '"+usr.getUsername();
				logMsg += "'; patient code: '"+patient.getCodpatient();
				logMsg += "'; interview: '"+intrv.getName()+"' ("+intrvId+")";
				
				logDb.customLog(sessId, lastIp, userId, intrv.getName(), logMsg);
				LogFile.info(logMsg);
				
				logMsg = "New performance id is "+perf.getId();
				LogFile.info(logMsg);
				
				return perf;
			}
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			errMsg = "The requested interview performance could not be recorded";
			LogFile.getLogger().error(errMsg);
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
			
			return null;
		}
		
	}
	
	
	
/**
 * Gets a row of the Performance table based mostly on codPat and usrId. If the
 * interview was performed by another user in the same group than the current
 * user.
 * In the case of the user has 'admin' role, the interview has to be displayed
 * The modified data has to be saved related to a right user
 * @param codPat, the code of the patient (not the patient id!!!!)
 * @param intrvId, the id of the interview
 * @param usrId, the id of the user who is gonna do the interview
 * @return
 */	
	public Performance getPerformance (String codPat, Integer intrvId, 
																		Integer usrId, String jspSess, String lastIp) {
		
		List<Performance> perfList;
		List<AppUser> userGrp;
		AppGroup grp = null;
/*		
		String hqlStrQry = "from Performance p where p.appuser in (:users) and "+
		"p.patient=:patient and p.interview=:intrv";
*/
		String hqlStrQry = "from Performance p where p.group=:grp and "+
		"p.patient=:patient and p.interview=:intrv";
		String hqlQryAdm = "from Performance p where p.patient=:patient " +
				"and p.interview:intrv";
		
		Transaction tx = null;
		try {
			AppUser user = (AppUser)hibSes.get(AppUser.class, usrId);
			
//			tx.commit();
// No transaction here because it is inside getUserPartners			
			AppUserCtrl usrCtrl = new AppUserCtrl(hibSes);
//			userGrp = usrCtrl.getUserPartners(user, HibernateUtil.HOSP_GROUPTYPE);
			if (!user.isAdmin())
				grp = usrCtrl.getSecondaryActiveGroup(user);
			
//			tx.begin();
			Interview intrv = (Interview)hibSes.get(Interview.class, intrvId);
			
			tx = hibSes.beginTransaction();
			String qry = "from Patient p where p.codpatient='"+codPat+"'";
			Query hqlQry = hibSes.createQuery(qry);
			Patient pat = (Patient)hqlQry.uniqueResult();

			if (pat == null)
				return null;
/*			
			String sqlQry = "select idperformance from performance where codpat = "+ pat.getId()+
					" and coduser in (";
			Iterator<AppUser> itUsr = userGrp.iterator();
			while (itUsr.hasNext()) {
				sqlQry += itUsr.next().getId()+",";
			}
			sqlQry = sqlQry.substring(0, sqlQry.length()-1)+")";
*/			
//			hqlQry = hibSes.createSQLQuery(sqlQry);
			if (user.isAdmin()) 
				hqlQry = hibSes.createQuery(hqlQryAdm);
			
			else { // an user with not admin role
				hqlQry = hibSes.createQuery(hqlStrQry);
//			hqlQry.setParameterList("users", userGrp);
				hqlQry.setEntity("grp", grp);
			}
			
			hqlQry.setEntity("patient", pat);
			hqlQry.setEntity("intrv", intrv);
			
//			perfList = hqlQry.list();
			
//			List<Integer>idsPerf = hqlQry.list();
			List<Performance> idsPerf = hqlQry.list();
			Performance perf = null;
			if (idsPerf != null && idsPerf.size() > 0)
//				perf = (Performance)hibSes.get(Performance.class, idsPerf.get(0));
				perf = idsPerf.get(0);
			
			tx.commit();
			
			if (perf != null) {
				String msgLog = "User '"+user.getUsername()+"': Resuming interview '"+
												intrv.getName()+"' ("+intrv.getId();
				msgLog += ") for patient '"+pat.getCodpatient()+"'";
				
				if (!jspSess.equalsIgnoreCase("")) {
					ActionsLogger logDb = new ActionsLogger (hibSes);
					
					logDb.customLog(jspSess, lastIp, usrId, intrv.getName(), msgLog);
					LogFile.info(msgLog);
				}
			}
			
			return perf;
		}
		catch (RuntimeException ex) {
			ex.printStackTrace();
			
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
		}
		return null;
	}
	
	
	
	
	/**
	 * Gets a row of the Performance table based mostly on codPat and usrId
	 * @param codPat, the code of the patient (not the patient id!!!!)
	 * @param intrvId, the id of the interview
	 * @param usrId, the id of the user who is gonna do the interview
	 * @param lastSec, the order of the last section completed
	 * @return
	 */	
		public boolean setLastSec (String codPat, Integer intrvId, 
																	 Integer usrId, int lastSec) {
//			Session theSes = HibernateUtil.getSessionFactory().getCurrentSession();
			Performance perf = getPerformance (codPat, intrvId, usrId, "", "");
			
			Transaction tx = null;
			try {
				tx = hibSes.beginTransaction();
				
				perf.setLastSec(new Integer(lastSec));
//				hibSes.save(perf);
				
				tx.commit();
			}
			catch (RuntimeException ex) {
				try {
					if (tx.isActive())
						tx.rollback();
				} 
				catch (RuntimeException rbEx) {
	// it would has to log something				
//					theSes.close();
					return false;
				}
//				throw ex;
				return false;
			} 
			finally {
//				theSes.close();
			}
			return true;
		}
	
	
/**
 * Saves the anser to the question and inserts a rown in the ternary relationship
 * to connect answer to question to patient
 * @param qId, the question id
 * @param ansNumber, the number of answer
 * @param ansOrder, the order of the anser
 * @param ansVal, the value of the answer
 * @param patId, the patient id
 * @param ait, the answer item corresponding to this answer
 * @return
 */	
	public boolean saveAnswer (Question q, Patient pat, Integer ansNumber, 
														Integer ansOrder, Integer ansGroup, String ansVal, AnswerItem ait) {
//		Session theSes = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = hibSes.beginTransaction();
		try {
			Answer newAns = new Answer (ansVal);
			newAns.setAnswerOrder(ansOrder);
			newAns.setAnswerItem(ait);
			hibSes.save(newAns);
			
			PatGivesAns2Ques row = new PatGivesAns2Ques(q, newAns, pat);
			row.setAnswerNumber(ansNumber);
			row.setAnswerOrder(ansOrder);
			if (ansGroup != null)
				row.setAnswerGrp(ansGroup);
			
			hibSes.save(row);
			
			tx.commit();
		}
		catch (RuntimeException ex) {
			try {
				if (tx.isActive())
					tx.rollback();
				
				ex.printStackTrace();
			} 
			catch (RuntimeException rbEx) {
// it would has to log something				
//				theSes.close();
				return false;
			}
//			throw ex;
		} 
		finally {
//			theSes.close();
		}
		return true;
	}


/**
 * Update the value of an answer from the answer id
 * @param ansId, the answer id to get the answer
 * @param newValue, the newvalue for the answer
 * @return
 */	
	public boolean updateAnswer (Integer ansId, String newValue) {
		Transaction tx = hibSes.beginTransaction();
		try {
			Answer theAns = (Answer)hibSes.get(Answer.class, ansId);
			theAns.setValue(newValue);
			
			tx.commit();
		}
		catch (RuntimeException ex) {
			try {
				if (tx.isActive())
					tx.rollback();
				
				ex.printStackTrace();
			} 
			catch (RuntimeException rbEx) {
// it would has to log something				
//				theSes.close();
				return false;
			}
//			throw ex;
		} 
		finally {
//			theSes.close();
		}
		return true;
	}
	
/**
 * Gets a Patient entity from the code assigned on interview time
 * @param patientCode, the code of the patient when assigned
 * @return a patient entity object
 */	
	public Patient getPatientFromCode (String patientCode) {
		// Session theSes = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try {
			tx = hibSes.beginTransaction();
			String qry = "from Patient p where p.codpatient='"+patientCode+"'";
			
			Query hqlQry = hibSes.createQuery(qry);
			Patient pat = (Patient)hqlQry.uniqueResult(); 
			tx.commit();
			
			return pat;
		}
		catch (RuntimeException ex) {
			if (tx != null)
				tx.rollback();
			
//			ex.printStackTrace();
			errMsg = "Could not retrieve patient from patient code";
			LogFile.getLogger().error(errMsg);
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
			
		}
		return null;
	}
	
	
	
	
/**
 * This method sees if the patient is allowed to be used by this group of users.
 * This is to avoid the same code is used in two different interviews done by
 * different users from different groups.
 * The only exception is with the NULL_PATIENT, which is allowed to be used by
 * everyone
 * @param pat, the patient
 * @param usrId, the id of the user who is developing the interview
 * @return true if the code for the patient is allowed to be used; otherwise
 * it returns false
 */	
	public boolean isPatientCodeAllowed (Patient pat, Integer usrId) {
		
		if (pat.getCodpatient().equals(TEST_PATIENT))
			return true;
		
		AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
/*		
		List<AppUser> groupUsrs = 
						usrCtrl.getUserPartners((AppUser)hibSes.get(AppUser.class, usrId), 
																	HibernateUtil.HOSP_GROUPTYPE);
		String hql = "from Performance where appuser in (:users) and patient=:pat";
*/		
		AppGroup grp = 
				usrCtrl.getSecondaryActiveGroup((AppUser)hibSes.get(AppUser.class, usrId));
		
		String hqlStr = "from Performance where group=:grp and patient=:pat";
		
		Transaction tx = null;
		try {
			tx = hibSes.beginTransaction();
/*			
			Query qry = hibSes.createQuery(hql);
			qry.setEntity("pat", pat);
			qry.setParameterList("users", groupUsrs);
*/
			Query qry = hibSes.createQuery(hqlStr);
			qry.setEntity("grp", grp);
			qry.setEntity("pat", pat);
			List<Performance> lPerf = qry.list();
			tx.commit();

// if the list is empty, the patient exists, has a performance but it was not
// developed by usrId or partners. so the code is not suitable for this user			
			if (lPerf == null || lPerf.isEmpty())
				return false;
			else // the patient has previous performances with usrId
				return true;
			
		}
		catch (HibernateException ex) {
			if (tx != null && tx.isActive())
				tx.rollback();
			
			errMsg = "Error while trying to check patient code allowed";
			LogFile.getLogger().error(errMsg);
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
			
			return false;
		}
	}
	
	
/*
 * This method check whether or not a patient code is allowed to be used by
 * the user represented by usrId. The patient is allowed if there is a
 * performance for this patient and the usrId belongs to the group which made
 * the performance to the patient. 
 * This method gets involved when an interviewer puts a patient code to start/
 * continue an interview
 * @param pat, the patient
 * @param usrId, the id of the user
 * @return the performance which was performed to the patient or null if the 
 * patient doesnt have interview for this user, which implies the patient is
 * not allowed for the user represented by usrId
 *	
	public Performance isPatientCodeAllowed (Patient pat, Integer usrId) {
		
		AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
		List<AppUser> groupUsrs = 
						usrCtrl.getUserPartners((AppUser)hibSes.get(AppUser.class, usrId), 
																	HibernateUtil.HOSP_GROUPTYPE);
		
		String hql = "from Performance where appuser in (:users) and patient=:pat";
		Transaction tx = null;
		try {
			tx = hibSes.beginTransaction();
			Query qry = hibSes.createQuery(hql);
			qry.setEntity("pat", pat);
			qry.setParameterList("users", groupUsrs);
			
			List<Performance> lPerf = qry.list();
			tx.commit();

// if the list is empty, the patient exists, has a performance but it was not
// developed by usrId or partners. so the code is not suitable for this user			
			if (lPerf == null || lPerf.isEmpty())
				return null;
			else // the patient has previous performances with usrId
				return lPerf.get(0);
			
		}
		catch (HibernateException ex) {
			if (tx != null && tx.isActive())
				tx.rollback();
			
			return null;
		}
	}
	*/
	
	
/*			
String hql = "select a.idanswer, a.thevalue, pga.answer_number, pga.answer_order," +
"a.answer_order from Answer a, AnswerItem ai, PatGivesAns2Ques pga" +
"where a.codansitem = ai.idansitem and pga.codanswer = a.idanswer" +
" and pga.codquestion = 51 and pga.codpat = 750	order by 4, 5;";
*/
/**
 * Gets the answers for a question made to a patient.  
 * @param q, the question
 * @param patId, the patient id (this is the database id, not the patient code)
 * @return a list of array of Object with:<br>
 * the answer id (Integer)
 * the answer value (String)
 * the answer number (Integer)
 * the answer order (Integer)
 * the answer order from answer table (Integer)
 * the answer item id which this answer belong to
 * the answer item name
 */	
	public List<Object[]> getAnswers (Question q, Integer patId, int numAns) {
		
//		Session hibSes = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		
		try {
			String strQry = 
				"select a.idanswer, a.thevalue, pga.answer_number, pga.answer_order," +
				" a.answer_order, ai.idansitem, ai.name " +
				"from answer a, answer_item ai, PAT_GIVES_ANSWER2QUES pga" +
				" where a.codansitem = ai.idansitem and pga.codanswer = a.idanswer" +
				" and pga.codquestion = "+q.getId()+" and pga.codpat = "+patId+
				" and pga.answer_number = "+numAns+"  order by 4, 5;";
/*			
			String hql = "select a.idanswer, a.thevalue, pga.answer_number, pga.answer_order," +
			"a.answer_order from Answer a, AnswerItem ai, PatGivesAns2Ques pga" +
			"where a.answerItem = ai and pga.answer = a" +
			" and pga.question = :ques and pga.codpat = "+patId+
			"	order by pga.answer_number asc, a.answer_order asc";
			
			tx = hibSes.beginTransaction();
			Query sql = hibSes.createQuery(hql);
			sql.setEntity("ques", q);
*/
			tx = hibSes.beginTransaction();
			SQLQuery sql = hibSes.createSQLQuery(strQry);
			List<Object[]> l = sql.list();
/*			
			if (l == null || l.size() == 0) {
				Object[] res = {null, "", 1, 1, 1, null, ""};
				if (l == null) {
					l = new ArrayList<Object[]>();
					l.add(res);
				}
				else // size is 0
					l.add(res);
			}
*/		
			tx.commit();
			
			return l;
		}
		catch (HibernateException ex){
			if (tx != null)
				if (tx.isActive())
					tx.rollback();
			
			errMsg = "Could not retrieve answers for question with id: "+q.getId();
			LogFile.getLogger().error(errMsg);
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
		}
		
		return null;
	}
	
	

/**
 * Return the number of answers for a, usually repeatable, question
 * @param q, the question
 * @param pat, the patient who the question was answered for
 * @return the number of different answers
 */	
	public int getNumOfAnswers (Question q, Integer patId) {
		String hql = "select count(distinct answer_number) " +
				"from PatGivesAns2Ques where question = :q and patient=:p";
		
		Transaction tx = null;
		try {
			tx = hibSes.beginTransaction();
			
			Patient pat = (Patient)hibSes.get(Patient.class, patId);
			Query qry = hibSes.createQuery(hql);
			qry.setEntity("q", q);
			qry.setEntity("p", pat);
			
			Long answerNum = (Long)qry.uniqueResult();
			
			return answerNum.intValue();
			
		}
		catch (HibernateException ex) {
			if (tx != null)
				if (tx.isActive())
					tx.rollback();
			
			errMsg = "Could not retrieve number of questions for question with id: "+
						q.getId();
			LogFile.getLogger().error(errMsg);
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
		}
		
		return -1;
	}
	
	
	
/**
 * Gets the answer as a Object[], where every position in the array is a 
 * Answer property, based on the response of a patient to a question in a
 * number of answer (in the case of repetitivity) and order of answer (for
 * questions with several answer values).
 * The array elements are like [207, 1, 1, 551] or, in general, 
 * [idAnswer, thevalue, answer_order, cod_ansitem}
 * @param idQues, the id of the question
 * @param idPat, the id of the patient
 * @param ansNum, number of answer (repetitivity)
 * @param ansOrd, the order of the answer
 * @param ansGroup, the group of the answer (GOTTA BE ADDED!!!!!!!!!!!!)
 * @return
 */	
	public Object[] getAnswer4Question (Integer idQues, Integer idPat, 
																Integer ansNum, Integer ansOrd) {
		Transaction tx = null;
		
		try {
			String strQry = "select a.*	from pat_gives_answer2ques pga, answer a " +
					"where pga.codquestion="+idQues+" and pga.answer_number = "+ansNum+" and " +
					"pga.answer_order = "+ansOrd+" and pga.codpat="+idPat+" and " +
					"pga.codanswer = a.idanswer	" +
					"order by pga.answer_number, pga.answer_order, pga.answer_grp;";
			
			String hqlQry = "from Answer a join a.patAnsQues paq where"+
					" paq.answerNumber ="+ansNum+" and paq.answerOrder="+ansOrd+
					" and paq.question.id="+idQues+
					" and paq.patient.id="+idPat+
					" order by pqa.answerNumber, pqa.answerOrder, pga.answerGrp";

			tx = hibSes.beginTransaction();
			SQLQuery sql = hibSes.createSQLQuery(strQry);
//			List<Object[]> l = sql.list();
			Object[] ans = (Object[])sql.uniqueResult();
//			Query qry = hibSes.createQuery(hqlQry);
//			Answer ans = (Answer)qry.uniqueResult();
			tx.commit();
			
			return ans;
		}
		catch (HibernateException ex){
			if (tx != null)
				if (tx.isActive())
					tx.rollback();
			
			errMsg = "Could not get answer for question...";
			LogFile.getLogger().error(errMsg);
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
		}
		return null;
	}
	
	
/**
 * Retrieves the error message for some error yielded during running 
 * @return
 */	
	public String getErrMsg () {
		return errMsg;
	}
	
	
// OjO con este method	
	protected void finalize () {
    if (hibSes != null) {
    	if (hibSes.isOpen())
        hibSes.close();
    }
	}
	
}