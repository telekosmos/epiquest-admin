package org.cnio.appform.util;

import static org.hibernate.criterion.Restrictions.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.AnnotatedClassType;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.*;

import org.cnio.appform.entity.*;

/**
 * This class contains methods to control the user properties
 * @author willy
 *
 */
public class AppUserCtrl {

	public static final Integer COD_ADMROLE = 50;
	
	public static final Integer COD_HOSPITAL_INI_ES = 1;
	public static final Integer COD_HOSPITAL_END_ES = 19;
	
	public static final Integer COD_HOSPITAL_INI_EN = 20;
	public static final Integer COD_HOSPITAL_END_EN = 29;
	
	public static final Integer COD_HOSPITAL_INI_IT = 30;
	public static final Integer COD_HOSPITAL_END_IT = 39;
	
	public static final Integer COD_HOSPITAL_INI_AT = 40;
	public static final Integer COD_HOSPITAL_END_AT = 49;
	
	public static final Integer COD_HOSPITAL_INI_DE = 50;
	public static final Integer COD_HOSPITAL_END_DE = 59;
	
	public static final Integer COD_HOSPITAL_INI_SE = 60;
	public static final Integer COD_HOSPITAL_END_SE = 69;
	
	public static final Integer COD_HOSPITAL_INI_IE = 70;
	public static final Integer COD_HOSPITAL_END_IE = 89;
	
	public static final int LOGIN_SUCCESS = 0;
	public static final int LOGIN_FAIL = 1;
	public static final int LOGIN_CONCURRENT = 2;
	
	public static final String ADMIN_ROLE = "ADMIN";
	public static final String EDITOR_ROLE = "EDITOR";
	public static final String INTRVR_ROLE = "INTERVIEWER";
//	public static final String GUEST_ROLE = "GUEST";
	public static final String GUEST_ROLE = "INVITED";
	public static final String DATAMGR_ROLE = "DATA MANAGER";
	public static final String CURATOR_ROLE = "CURATOR";
	public static final String DUMMY1_ROLE = "DUMMY1";
	public static final String DUMMY2_ROLE = "DUMMY2";
	
// This final fields are intended to use as roles in the permission methods
	public static final int ROLE_ADM = 0; // admin (000)
	public static final int ROLE_EDI = 1; // editor (001)
	public static final int ROLE_INT = 3; // interviewer (011)
	public static final int ROLE_INV = 2; // guest (010)
	public static final int ROLE_DMG = 6; // data manager (110)
	public static final int ROLE_CUR = 7; // curator (111)
	public static final int ROLE_DUM1 = 5; // dummy 1 (101)
	public static final int ROLE_DUM2 = 4; // dummy 2 (100)
	
// This final field are intended to use as actions in the permission methods
	public static final int ACTION_C = 0;
	public static final int ACTION_R = 1;
	public static final int ACTION_U = 3;
	public static final int ACTION_D = 2;
	
	public static final String ADM_MAIL = "gcomesana@cnio.es";
	
	private Session theSess;
	

	
	public AppUserCtrl (Session aSession) {
		theSess = aSession;
	}

	
/**
 * This method checks whether or not the role is allowed to perform the specified 
 * action on a project
 * @param role, a comma separated role names
 * @param action, the action to be performed on the project
 * @return
 */
	public static boolean projectPermissions (String rolenames, int action) {
		String roles[] = rolenames.split(",");
		boolean granted = false;
		
		for (String rolename: roles) {
			int role = AppUserCtrl.role2Code(rolename);
			
			if (role == AppUserCtrl.ROLE_ADM) {
				granted = true;
				break;
			}
			else if (action == AppUserCtrl.ACTION_R) {
				granted = true;
				break;
			}	
			else
				return false;
		}
		return granted;
	}
	
	

/**
 * This method checks whether or not the role is allowed to perform the specified 
 * action on a interview
 * @param role, a comma separated list of role names
 * @param action, the action to be performed on the project
 * @return
 */
	public static boolean intrvPermissions (String rolenames, int action) {
		String roles[] = rolenames.split(",");
		boolean granted = false;
		
		for (String rolename: roles) {
			int role = AppUserCtrl.role2Code(rolename);
			
			if (role == AppUserCtrl.ROLE_EDI) {
				granted = true;
				break;
			}
			else if (action == AppUserCtrl.ACTION_R) {
				granted = true;
				break;
			}	
			else if ((role == AppUserCtrl.ROLE_EDI || role == AppUserCtrl.ROLE_ADM) &&
							 (action == AppUserCtrl.ACTION_U || action == AppUserCtrl.ACTION_D)) {
				granted = true;
				break;
			}
			else
				return false;
		}
		return granted;
	}	
	

	
/**
 * This method checks whether or not the role is allowed to perform the specified 
 * action on a performance
 * @param rolenames, a string with the role names comma separated.
 * @param action, the action to be performed on the project
 * @return
 */
	public static boolean performancePermissions (String rolenames, int action) {
		String roles[] = rolenames.split(",");
		boolean granted = false;
		
		for (String rolename: roles) {
			int role = AppUserCtrl.role2Code(rolename);
			
			if (role == AppUserCtrl.ROLE_EDI || role == AppUserCtrl.ROLE_INT) {
				granted = true;
				break;
			}
			else if ((role == AppUserCtrl.ROLE_EDI || role == AppUserCtrl.ROLE_ADM) &&
							 (action == AppUserCtrl.ACTION_R || action == AppUserCtrl.ACTION_U ||
								action == AppUserCtrl.ACTION_D)
							) {
				granted = true;
				break;
			}	
			else if ((role == AppUserCtrl.ROLE_INT || role == AppUserCtrl.ROLE_CUR) &&
							 (action == AppUserCtrl.ACTION_R || action == AppUserCtrl.ACTION_U)) {
				granted = true;
				break;
			}
			else if ((role == AppUserCtrl.ROLE_DMG || role == AppUserCtrl.ROLE_CUR) &&
								action == AppUserCtrl.ACTION_R) {
				granted = true;
				break;
			}
				
			else
				return false;
		}
		return granted;
	}		

	
/**
 * Gets the permission to access to a section element (this means, to access
 * the element edition page). This is needed as the disable element applied on
 * multiple selection list dont work properly
 * @param rolenames, a string with the role names comma separated.
 * @param action, the action to be performed on the project
 * @return true if the action is allowed for any of the rolenames; false
 * otherwise
 */
	public static boolean elemPermissions (String rolenames, int action) {
		String roles[] = rolenames.split(",");
		boolean granted = false;
		
		for (String rolename: roles) {
			int role = AppUserCtrl.role2Code(rolename);
			
			if (role == AppUserCtrl.ROLE_EDI || role == AppUserCtrl.ROLE_ADM) {
				granted = true;
				break;
			}
		}
		return granted;
	}
	
	
	
/**
 * Handy method to convert a role name to a internal code to get the 
 * permissions
 * @param rolename
 * @return the internal role code to use in the permission methods
 */	
	private static int role2Code (String rolename) {
		if (rolename.equalsIgnoreCase(AppUserCtrl.ADMIN_ROLE))
			return AppUserCtrl.ROLE_ADM;
		
		if (rolename.equalsIgnoreCase(AppUserCtrl.EDITOR_ROLE))
			return AppUserCtrl.ROLE_EDI;
		
		if (rolename.equalsIgnoreCase(AppUserCtrl.INTRVR_ROLE))
			return AppUserCtrl.ROLE_INT;
		
		if (rolename.equalsIgnoreCase(AppUserCtrl.CURATOR_ROLE))
			return AppUserCtrl.ROLE_CUR;
		
		if (rolename.equalsIgnoreCase(AppUserCtrl.DATAMGR_ROLE))
			return AppUserCtrl.ROLE_DMG;
		
		if (rolename.equalsIgnoreCase(AppUserCtrl.DUMMY1_ROLE)	)
			return AppUserCtrl.ROLE_DUM1;
		
		if (rolename.equalsIgnoreCase(AppUserCtrl.DUMMY2_ROLE))
			return AppUserCtrl.ROLE_DUM2;
		
// finally, return the guest role code
		return AppUserCtrl.ROLE_INV;
		
	}
	
	
	
/**
 * Get the list of roles for a user
 * @param username, the user name
 * @return a list of Role objects
 */	
	public List<Role> getRoleFromUser (AppUser usr) throws HibernateException {
		String sqlQuery = "select r.* from appuser a, role r, user_role ur " +
				"where a.username='"+usr.getUsername()+"' and a.iduser = ur.coduser " +
						"and ur.codrole = r.idrole";
		
		String hql = "from Role r join r.userRoles ur where ur.theUser=:user";
	
//		Session theSess = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		List<Role> l = null;
		try {
			tx = theSess.beginTransaction();
			Query qry = theSess.createQuery(hql);
			qry.setEntity("user", usr);
			
			List<Object[]> aux = qry.list();
			l = new ArrayList<Role>();
			for (Iterator<Object[]> it=aux.iterator(); it.hasNext();) {
				Object[] pair = it.next();
				l.add((Role)pair[0]);
			}
			
			tx.commit();
		}
		catch (HibernateException hibEx) {
			if (tx != null) {
				tx.rollback();
			}
			l = null;
		}
		
		return l;
	}
	
	
/**
 * Returns the hospital code, which is the code to group people, related to the
 * user represented by username
 * @param username, the String user name
 * @return
 */	
	public Integer getCodHospital (String username) throws HibernateException {
//		Session theSess = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = theSess.beginTransaction();
		Criteria ct = theSess.createCriteria(AppUser.class).add(Restrictions.eq("username", username));
		AppUser theUser = (AppUser)ct.uniqueResult();
		
		Hospital h = theUser.getTheHospital();
		tx.commit();
		if (h != null)
			return h.getHospCod();
		else
			return null;
	
	}
	

		
/**
 * Retrieve all rows from the appuser table
 * @return a list of users
 */		
	public List<AppUser> getOnlyUsers () {
		Criteria ct = null;
		Transaction tx = null;
		List<AppUser> l = null;
		try {
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}
			
			ct = theSess.createCriteria(AppUser.class);
			l = ct.list();
			
			if (doCommit)
				tx.commit();
			
		}
		catch (HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			
			String msgLog = "Unable to retrieve users from DB";
			StackTraceElement[] stack = hibEx.getStackTrace();
			LogFile.error(msgLog);
			LogFile.logStackTrace(stack);
		}
		
		return l;
	}
		
	
	
/**
 * Retrieves all users and their correspondent roles ids
 * @return a list of objecst, where every object is a row with the user info
 * and the role id (i guess)
 */	
	public List<Object[]> getAllUsers () {
		List<Object[]> aux = null;
		String hqlStr = "from AppUser a join a.userRoles u order by a.username";
		
		Query q = theSess.createQuery(hqlStr);
		aux = q.list();
		return aux;
	}
	
	
	
/**
 * Gets an user from his/her user name
 * @param username, the name of the user for the application
 * @return
 */	
	public AppUser getUser (String username) throws HibernateException {
//		Session theSess = HibernateUtil.getSessionFactory().getCurrentSession();
//		Transaction tx = theSess.beginTransaction();
		
		Criteria ct = theSess.createCriteria(AppUser.class).add(Restrictions.eq("username", username));
		AppUser theUser = (AppUser)ct.uniqueResult();
		
//		tx.commit();
		
		return theUser;
	}
	
	
/**
 * Gets the list of groups which a user belongs to
 * @param usr, the user
 * @return a list of groups for the user
 * @throws HibernateException

	public List<Object[]> getGroups (AppUser usr) throws HibernateException {
		
		String hql = "from RelGrpAppuser a where a.appuser = :user";
		String users = "select a.iduser, a.username from appuser a, rel_grp_appusr ga " +
				"where ga.codgroup in "; // 1 and ga.coduser = a.iduser";
		
//		Session theSess = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = theSess.beginTransaction();
		Query q = theSess.createQuery(hql);
		q.setEntity("user", usr);
		
		String groups = "(";
		List<RelGrpAppuser> l = q.list();
		for (RelGrpAppuser ga: l)
			groups += ga.getAppgroup().getId()+",";
		
		groups = groups.substring(0, groups.length()-1)+") ";
		users += groups + "and ga.coduser = a.iduser";

		SQLQuery usrsQry = theSess.createSQLQuery(users);
		
		List<Object[]> lUsrs = usrsQry.list();
		tx.commit();
		
		return null;
	}
*/
	
	
	
	
/**
 * Gets the list of groups which a user belongs to
 * @param usr, the user
 * @return a list of groups for the user
 * @throws HibernateException
 */
	public List<AppGroup> getGroups (AppUser usr) throws HibernateException {
		
		String hql = "from RelGrpAppuser r where r.appuser=:user",
					hqlAdm = "from AppGroup",
					superhql = "select a from AppGroup a join a.relGrpAppusrs r " +
							"where r.appuser=:user";
		
		Transaction tx = null;
		Query qry = null;
		List<RelGrpAppuser> lGrps;
		List<AppGroup> aux = null;
		try {
/*
			tx = theSess.getTransaction();
			tx = (tx.isActive() == true)? tx: theSess.beginTransaction();
*/
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}
// we consider the admin belongs to all groups			
			if (usr.isAdmin()) { 
				qry = theSess.createQuery(hqlAdm);
				aux = qry.list();
				
				if (doCommit)	
					tx.commit();
			}
			else { // for the rest of users
//				qry = theSess.createQuery(hql);
				qry = theSess.createQuery(superhql);
				qry.setEntity("user", usr);
			
//				lGrps = qry.list();
				aux = qry.list();
				if (doCommit)
					tx.commit();
/*				
				aux = new ArrayList<AppGroup>();
				for (RelGrpAppuser item: lGrps)
					aux.add(item.getAppgroup());*/
			}
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			String msgLog = "Unable to create a new interview '"+usr.getUsername()+"'";
			LogFile.error(msgLog);
			LogFile.error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
			
			return null;
		}
		
		return aux;
	}	
	

	
	
	
/**
 * Gets all groups defined in the application
 * @return a list of groups (AppGroup objects)
 */	
	public List<AppGroup> getAllGroups () {
		String hql = "from AppGroup";
		List<AppGroup> lGrp;
		
		Transaction tx = theSess.beginTransaction();
		Query q = theSess.createQuery(hql);
		
		lGrp = q.list();
		tx.commit();
		
		return lGrp;
	}
	
	
/**
 * Gets all projects currently working in the application
 * @return a list of projects (Project objects)
 */	
	public List<Project> getAllProjects () {
		String hql = "from Project";
		List<Project> lPrj;
		
		Transaction tx = theSess.beginTransaction();
		Query q = theSess.createQuery(hql);
		
		lPrj = q.list();
		tx.commit();
		
		return lPrj;
	}
	
	
/**
 * Gets all roles currently defined in the application
 * @return a list of roles (Role objects)
 */	
	public List<Role> getAllRoles () {
		String hql = "from Role";
		List<Role> lRole;
		
		Transaction tx = theSess.beginTransaction();
		Query q = theSess.createQuery(hql);
		
		lRole = q.list();
		tx.commit();
		
		return lRole;
	}
	
	
	
/**
 * Gets all users belonging to the same group than user, user included. The
 * group is defined by the param group type
 * @param user, the user whose partners are gonna be got
 * @return
 */	
	public List<AppUser> getUserPartners (AppUser user, String grpTypeName) {
		String sqlQry = "select a.iduser from appuser a, rel_grp_appusr rga" +
				" where a.iduser = rga.coduser and rga.codgroup in" +
				" (select rga.codgroup from appuser a, rel_grp_appusr rga, appgroup g" +
				" where a.iduser = rga.coduser and a.iduser = "+user.getId()+
				" and rga.codgroup = g.idgroup " +
				"and g.codgroup_type = " +
				" (select idgrouptype from grouptype where name = '"+
//				HibernateUtil.HOSP_GROUPTYPE+"'));";
				grpTypeName+"'));";
		
		String hqlQryBad = "select a from AppUser a join a.relGrpAppusrs b " +
				"where b.appgroup in (select d.appgroup " +
				"from AppUser c join c.relGrpAppusrs d " +
				"where c = :user)";
		
		Transaction tx = null;
		tx = theSess.beginTransaction();
		Query q = theSess.createSQLQuery(sqlQry);
				
		List<Integer> l = q.list();
		List<AppUser> lUsr = new ArrayList<AppUser>();
		
		Iterator<Integer> it = l.iterator();
		while (it.hasNext()) {
			AppUser usr = (AppUser)theSess.get(AppUser.class, it.next());
			lUsr.add(usr);
		}
			
		tx.commit();
		
		return lUsr;
	}
	
	
	
/**
 * Gets all users belonging to the same hospital and the users with rol admin
 * @param username the name of the user
 * @return
 *	
	public List<AppUser> getGroup (String username) throws HibernateException {
		String sql = "select * from appuser a where a.codhosp = " +
				"(select u.codhosp from appuser u where u.username='"+username+"') " +
						"or a.iduser = (select a.iduser from appuser a, user_role ur " +
						"where a.iduser = ur.coduser and ur.codrole = "+AppUserCtrl.COD_ADMROLE+
						");";
//		Session theSess = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = theSess.beginTransaction();
		
		List<AppUser> l = 
			theSess.createSQLQuery(sql).addEntity(AppUser.class).list();
		tx.commit();
		
		return l;
	}
*/	
	
	
	private Integer getCodHospIni (String country) {
		
		if (country.equalsIgnoreCase("es"))
			return AppUserCtrl.COD_HOSPITAL_INI_ES;
		
		if (country.equalsIgnoreCase("en"))
			return AppUserCtrl.COD_HOSPITAL_INI_EN;
		
		if (country.equalsIgnoreCase("it"))
			return AppUserCtrl.COD_HOSPITAL_INI_IT;
		
		if (country.equalsIgnoreCase("at"))
			return AppUserCtrl.COD_HOSPITAL_INI_AT;
		
		if (country.equalsIgnoreCase("de"))
			return AppUserCtrl.COD_HOSPITAL_INI_DE;
		
		if (country.equalsIgnoreCase("se"))
			return AppUserCtrl.COD_HOSPITAL_INI_SE;
		
		if (country.equalsIgnoreCase("ie"))
			return AppUserCtrl.COD_HOSPITAL_INI_IE;
		
		else
			return AppUserCtrl.COD_HOSPITAL_INI_ES;
	}
	
	
	private Integer getCodHospEnd (String country) {
		
		if (country.equalsIgnoreCase("es"))
			return AppUserCtrl.COD_HOSPITAL_END_ES;
		
		if (country.equalsIgnoreCase("en"))
			return AppUserCtrl.COD_HOSPITAL_END_EN;
		
		if (country.equalsIgnoreCase("it"))
			return AppUserCtrl.COD_HOSPITAL_END_IT;
		
		if (country.equalsIgnoreCase("at"))
			return AppUserCtrl.COD_HOSPITAL_END_AT;
		
		if (country.equalsIgnoreCase("de"))
			return AppUserCtrl.COD_HOSPITAL_END_DE;
		
		if (country.equalsIgnoreCase("se"))
			return AppUserCtrl.COD_HOSPITAL_END_SE;
		
		if (country.equalsIgnoreCase("ie"))
			return AppUserCtrl.COD_HOSPITAL_END_IE;
		
		else
			return AppUserCtrl.COD_HOSPITAL_END_ES;
	}
	
	
/**
 * Gets all users belonging to the hospitals in the same country 
 * and the users with rol admin. This has to be improved because the hospitals
 * codes are "hardwritten"
 * @param country, the country initial to limit the range of hospitals
 * @return
 * @deprecated you should use getMainGroup (Appuser usr)
 */	
	@Deprecated public List<AppUser> getCountryGroup (String country) throws HibernateException {
		
		Integer codIni = this.getCodHospIni(country);
		Integer codEnd = this.getCodHospEnd(country);
		
		String sql = "select * from appuser a where a.codhosp in " +
				"(select idhosp from hospital where hospcod between " +
				codIni+" and "+ codEnd +") " +
						"or a.iduser = (select a.iduser from appuser a, user_role ur " +
						"where a.iduser = ur.coduser and ur.codrole = "+AppUserCtrl.COD_ADMROLE+
						");";
//		Session theSess = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = theSess.beginTransaction();
		List<AppUser> l = 
			theSess.createSQLQuery(sql).addEntity(AppUser.class).list();
		
		tx.commit();
		return l;
	}
	
	

/**
 * Retrieve the list of projects assigned to the user
 * @param user, the user whose projects are gonna be retrieved
 * @return
 */	
	public List<Project> getProjects (AppUser user) {
		String hql = "from Project p where p.relPrjAppuserses.appuser=:user",
			hqlBis = "from Project p join p.relPrjAppuserses rpa where "+
			"rpa.appuser=:user",
			hqlAdm = "from Project";
		Query qry;
/*		
		String hqlIntrBis = "from Interview i join i.relIntrvGrps rig where" +
		" rig.appgroup=:group and i.parentPrj=:prj";
*/		
		Transaction tx = null;
		List<Project> prjs = null;
		try {
			tx = theSess.beginTransaction();
			
			if (user.isAdmin()) {
				qry = theSess.createQuery(hqlAdm);
				prjs = qry.list();
			}
			else {
				qry = theSess.createQuery(hqlBis);
				qry.setEntity("user", user);
				List<Object[]> aux = qry.list();
				
				Iterator<Object[]> itAux = aux.iterator();
				prjs = new ArrayList<Project>();
				while (itAux.hasNext()) {
					Object[] pair = (Object[])itAux.next();
					prjs.add((Project)pair[0]);
				}
			}
			
			tx.commit();
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
		}
		
		return prjs;
	}
	
	
	
	
/**
 * Set or unset the activation for the group. Unset any previously active group
 * @param user, the user who this session belongs to
 * @param group, the group which it is required to be activated
 * @param setting, the new state for the group: 0, unset; >=1 set active
 * @return true on successful completion of transaction; false otherwise
 */
	public boolean setActiveGroup (AppUser user, AppGroup group, Integer setting) {
		boolean res = false;
		String hqlStr = "from RelGrpAppuser r where r.appgroup=:grp and r.appuser=:user";
		List<RelGrpAppuser> relGroups = null;
		AppGroup prevGrp = null;
		
// get the proper active group to deactivate it
		String grpType = group.getType().getName();
		if (grpType.equalsIgnoreCase(HibernateUtil.MAIN_GROUPTYPE))
			prevGrp = getPrimaryActiveGroup (user);
		else
			prevGrp = getSecondaryActiveGroup (user);
		
		Transaction tx = null;
		try {
//					tx = theSess.getTransaction();
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}
		
// First, it deactivates prevGrp if the new one is going to become active
			Query hqlQry = theSess.createQuery(hqlStr);
			if (prevGrp != null && setting == 1) {
				hqlQry.setEntity("user", user);
				hqlQry.setEntity("grp", prevGrp);
				
				relGroups = hqlQry.list();
				relGroups.get(0).setActive(0);
			}
			
			hqlQry.setEntity("user", user);
			hqlQry.setEntity("grp", group);
			relGroups = hqlQry.list();
			
// I just have to get ONE result (there should be just one relation per group
// and user
			if (relGroups != null && relGroups.size() == 1) {
				RelGrpAppuser rel = relGroups.get(0);
				rel.setActive(setting);
				res = true;
			}
			
			if (doCommit)
				tx.commit();
			
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			String msgLog = "Unable to set active group '"+
											group.getName()+"' for user '"+user.getUsername()+"'";
			LogFile.error(msgLog);
			LogFile.error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
			return res;
		}
		
		return res;
	}
	
	
	
/**
 * Gets the group template/interview holder which the user belongs to
 * @param user
 * @return the secondary group set as active for the user or null if no group of
 * this type
 */	
	public AppGroup getSecondaryActiveGroup (AppUser user) {
		
		List<AppGroup> groups = null;
		AppGroup activeGrp = null;
		String hql = "select g from AppGroup g join g.relGrpAppusrs r where " +
				"g.type.name='"+HibernateUtil.HOSP_GROUPTYPE+
				"' and r.active=1 and r.appuser=:user";
		
		Transaction tx = null;
		try {
//					tx = theSess.getTransaction();
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}
			
			Query hqlQry = theSess.createQuery(hql);
			hqlQry.setEntity("user", user);
			groups = hqlQry.list();
			if (doCommit)
				tx.commit();
			
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			String msgLog = "Unable to get main group for user '"+user.getUsername()+"'";
			LogFile.error(msgLog);
			LogFile.error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
			return null;
		}
		
		if (groups != null && groups.size() > 0)
			activeGrp = groups.get(0);
		
		return activeGrp;
	}	
	
	
	
/**
 * Gets the secondary group (a hospital in this case, it can be a dept in some
 * other) for the user. 
 * UP UNTIL NOW, ONE USER CAN BELONG JUST TO A SECONDARY AND MAIN GROUP. 
 * Otherwise, interviews and performances are impossible to assign to a group.
 * For an admin, this would return all groups
 * @param user, the user
 * @return the group which the user belongs to if any.
 */	
	public AppGroup getSecondaryGroup (AppUser user) {
		
		List<AppGroup> groups = getGroups(user);
		List<AppGroup> aux = null;
		String hqlGrps = "from AppGroup g where g in (:groups) and g.type.name='"+
					HibernateUtil.HOSP_GROUPTYPE+"'";
		
		Query qry = null;
		List<RelGrpAppuser> lGrps;
		
		Transaction tx = null;
		AppGroup group = null;
		try {
			tx = theSess.beginTransaction();
/*			
			qry = theSess.createQuery(hql);
			qry.setEntity("user", user);
			lGrps = qry.list();
			
			groups = new ArrayList<AppGroup>();
			for (RelGrpAppuser item: lGrps)
				groups.add (item.getAppgroup());
*/			
			if (groups != null) {
				qry = theSess.createQuery(hqlGrps);
				qry.setParameterList("groups", groups);
				aux = qry.list();
			}
			tx.commit();
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
			
			return null;
		}
		
		if (aux != null && aux.size()>0)
			group = aux.get(0);
		
		return group;
	}
	
	
	
/**
 * Gets the secondary groups for the user
 * @param user
 * @return a list of secondary groups (intended as labs or hospitals in this 
 * application, departments in a more generic way) or null if nothing was found
 */
	public List<AppGroup> getSecondaryGroups (AppUser user) {
		
		List<AppGroup> lGrps = null;
		String hql = "select a from AppGroup a join a.relGrpAppusrs r where a.type.name='"+
			HibernateUtil.HOSP_GROUPTYPE+"' and r.appuser=:user";
		
		Transaction tx = null;
		AppGroup group = null;
		Query qry = null;
		try {
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}

			qry = theSess.createQuery(hql);
			qry.setEntity("user", user);
			lGrps = qry.list();
			
			if (doCommit)
				tx.commit();
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
			
			return null;
		}
		
		return lGrps;
	}
	
	
	
	
/**
 * Gets the group template/interview holder which the user belongs to
 * @param user
 * @return
 */	
	public AppGroup getPrimaryActiveGroup (AppUser user) {
		
		List<AppGroup> groups = null;
		AppGroup activeGrp = null;
		String hql = "select g from AppGroup g join g.relGrpAppusrs r where " +
				"g.type.name='"+HibernateUtil.MAIN_GROUPTYPE+
				"' and r.active = 1 and r.appuser=:user";
		
		String hqlName = "from AppGroup g where g.type.name='"+
					HibernateUtil.MAIN_GROUPTYPE+"'";
		Transaction tx = null;
		try {
//				tx = theSess.getTransaction();
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}
			
			Query hqlQry = theSess.createQuery(hql);
			hqlQry.setEntity("user", user);
			groups = hqlQry.list();
			if (doCommit)
				tx.commit();
			
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			String msgLog = "Unable to get main group for user '"+user.getUsername()+"'";
			LogFile.error(msgLog);
			LogFile.error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
			return null;
		}
		
		if (groups != null && groups.size()>0)
			activeGrp = groups.get(0);
		
		return activeGrp;
	}
	
	
	
/**
 * Gets the group template/interview holder which the user belongs to
 * @param user
 * @return
 */	
	public AppGroup getPrimaryGroup (AppUser user) {
		
		List<AppGroup> groups = null;
		List<AppGroup> aux = null;
		String hql = "select g from AppGroup g where g in (:groups) and g.type.name='"+
					HibernateUtil.MAIN_GROUPTYPE+"'";
		
		Transaction tx = null;
		AppGroup group = null;
		try {
			groups = getGroups(user);
			
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}
//			tx = (tx.isActive() == true)? tx: theSess.beginTransaction();
			
			if (groups != null) {
				Query qry = theSess.createQuery(hql);
				qry.setParameterList("groups", groups);
				aux = qry.list();
			}
			if (doCommit)
				tx.commit();
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			String msgLog = "Unable to get main group for user '"+user.getUsername()+"'";
			LogFile.error(msgLog);
			LogFile.error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
			return null;
		}
		
		if (aux != null && aux.size()>0)
			group = aux.get(0);
		
		return group;
	}
	
	
/**
 * Gets the secondary groups for the user
 * @param user
 * @return a list of main groups (intended as countries in this 
 * application, companies in a more generic way) or null if nothing was found
 */
	public List<AppGroup> getPrimaryGroups (AppUser user) {
		
		List<AppGroup> lGrps = null;
		String hql = "select a from AppGroup a join a.relGrpAppusrs r where a.type.name='"+
			HibernateUtil.MAIN_GROUPTYPE+"' and r.appuser=:user";
		
		Transaction tx = null;
		AppGroup group = null;
		Query qry = null;
		try {
			boolean doCommit = false;
			tx = theSess.getTransaction();
			if (tx == null || tx.isActive() == false) {
				tx = theSess.beginTransaction();
				doCommit = true;
			}

			qry = theSess.createQuery(hql);
			qry.setEntity("user", user);
			lGrps = qry.list();
			
			if (doCommit)
				tx.commit();
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			LogFile.getLogger().error(ex.getLocalizedMessage());
			StackTraceElement[] stElems = ex.getStackTrace();
			LogFile.logStackTrace(stElems);
			
			return null;
		}
		
		return lGrps;
	}
	
	

/**
 * Gets all group types currently registered.
 * @return the list of all group types or null whether some error has happened
 */	
	public List<GroupType> getGroupTypes () {
		List<GroupType> aux = null;
		String hqlStr = "from GroupType";
		Transaction tx = null;
		try {
			tx = theSess.beginTransaction();
			Query hqlQry = theSess.createQuery(hqlStr);
			aux = hqlQry.list();
			tx.commit();
			
			return aux;
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			return null;
		}
	}
	
	
//////////////////////////////////////////////////////////////////////////////
//////// METHODS TO HANDLE THE RELATIONSHIP USER-GROUP ///////////////////////
//////////////////////////////////////////////////////////////////////////////	
/**
 * Create a group to gather users in it
 * @param name, the name of the group
 * @return
 */	
	public int createGroup (String name, String grpCode, Integer grpTypeId) {
			
		Transaction tx = null;
		try {
			tx = theSess.beginTransaction();
			AppGroup group = new AppGroup (name);
			group.setCodgroup(grpCode);
			Integer grpId = (Integer)theSess.save(group);
			
			GroupType gt = (GroupType)theSess.get(GroupType.class, grpTypeId);
			if (gt != null)
				group.setType(gt);
			
			tx.commit();
			
			return grpId.intValue();
		}
		catch (HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			
			return -1;
		}
	}
	
	
	
/**
 * Add a user to a group
 * @param app
 * @param grp
 * @return
 * @throws HibernateException
 */	
	public boolean addUser2Group (AppUser user, AppGroup grp) throws HibernateException {
		Transaction tx = theSess.beginTransaction();
		
		RelGrpAppuser rga = new RelGrpAppuser (grp, user);
		tx.commit();
			
		return true;
	}
	
	
	
/**
 * Add an user to a project
 * @param app
 * @param grp
 * @return
 * @throws HibernateException
 */	
	public boolean addUser2Prj (AppUser user, Project prj) throws HibernateException {
		Transaction tx = theSess.beginTransaction();
		
		RelPrjAppusers rpa = new RelPrjAppusers (prj, user);
		tx.commit();
			
		return true;
	}	
	
	

/**
 * Remove an user from a group. Reminder: one user can be in more than one group
 * and one group holds more than one user
 * @param user
 * @param grp
 * @return true on successful completion, false if no group for this user exists
 * @throws HibernateException
 */	
	public boolean rmvUserFromGroup (AppUser user, AppGroup grp) 
																				throws HibernateException {
		Transaction tx = null;
		RelGrpAppuser rga;
		List<RelGrpAppuser> lUsers;
		String hql = "from RelGrpAppuser where appgroup=:grp and appuser=:usr";
		Query qry = null;
		
		
		try {
			tx = theSess.beginTransaction();
			
			qry = theSess.createQuery(hql);
			qry.setEntity("grp", grp);
			qry.setEntity("usr", user);
			rga = (RelGrpAppuser)qry.uniqueResult();
			
			theSess.delete(rga);
			tx.commit();
		}
		catch (org.hibernate.NonUniqueResultException ex) {
			if (qry != null) {
				lUsers = qry.list();
				if (lUsers == null || lUsers.size() == 0)
					return false;
				else
					rga = lUsers.get(0);
			}
			else
				return false;
		}
		catch (HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			return false;
		}
		
		return true;
	}
	
	
	
/**
 * Remove a user from a project
 * @param user
 * @param grp
 * @return true on successful completion, false if no group for this user exists
 * @throws HibernateException
 */	
	public boolean rmvUserFromPrj (AppUser user, Project prj) 
																				throws HibernateException {
		Transaction tx = null;
		RelPrjAppusers rpa;
		List<RelPrjAppusers> lUsers;
		String hql = "from RelGrpAppuser where project=:prj and appuser=:usr";
		Query qry = null;
		
		try {
			tx = theSess.beginTransaction();
			qry = theSess.createQuery(hql);
			qry.setEntity("prj", prj);
			qry.setEntity("usr", user);
			
			rpa = (RelPrjAppusers)qry.uniqueResult();
			
			theSess.delete(rpa);
			tx.commit();
		}
		catch (org.hibernate.NonUniqueResultException ex) {
			if (qry != null) {
				lUsers = qry.list();
				if (lUsers == null || lUsers.size() == 0)
					return false;
				else
					rpa = lUsers.get(0);
			}
			else
				return false;
		}
		catch (HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			
			return false;
		}
		
		return true;
	}	
	
	

//////////////////////////////////////////////////////////////////////////////
////////METHODS TO HANDLE THE RELATIONSHIP USER-ROLE ///////////////////////
//////////////////////////////////////////////////////////////////////////////	

/**
 * Create a new role
 * @param name, the name assigned to the role
 * @return
 */	
	public int createRole (String name) {
			
		Transaction tx = null;
		try {
			tx = theSess.beginTransaction();
			Role role = new Role (name, "");
			
			Integer rolId = (Integer)theSess.save(role);
			
			tx.commit();
			
			return rolId.intValue();
		}
		catch (HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			
			return -1;
		}
	}
	
	
		
/**
 * Add a user to a role
 * @param user
 * @param role
 * @return
 * @throws HibernateException
 */	
	public boolean addUser2Role (AppUser user, Role role) throws HibernateException {
		Transaction tx = theSess.beginTransaction();
		
		AppuserRole ur = new AppuserRole (user, role);
		tx.commit();
			
		return true;
		
	}
	

/**
 * Remove a role from a user
 * @param user
 * @param role
 * @return true on successful completion, false if no role for this user exists
 * @throws HibernateException
 */		
	public boolean rmvRoleFromUser (AppUser user, Role role) 
																				throws HibernateException {
		Transaction tx = null;
		AppuserRole rga;
		List<AppuserRole> lUsers;
		String hql = "from AppuserRole where theRole=:role and theUser=:usr";
		Query qry = null;
		
		try {
			tx = theSess.beginTransaction();
			qry = theSess.createQuery(hql);
			qry.setEntity("role", role);
			qry.setEntity("usr", user);
			
			rga = (AppuserRole)qry.uniqueResult();
			theSess.delete(rga);
			
			tx.commit();
		}
		catch (org.hibernate.NonUniqueResultException ex) {
			if (qry != null) {
				lUsers = qry.list();
				if (lUsers == null || lUsers.size() == 0)
					return false;
				else
					rga = lUsers.get(0);
			}
			else
				return false;
		}
		catch (org.hibernate.HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			
			return false;
		}
		return true;
	}
		
	
	
	
/**
 * Inserts a new row in the log table to record the session starting for a user
 * @param userId, the user id for the application
 * @param userName, the user name
 * @param roles, the role(s) for this user
 * @param sessionId, the session id assigned by the server
 * @param result, true if the user logged in successfully; false otherwise
 * @return true on successful completion; false otherwise
 */
	public boolean logSessionInit (Integer userId, String userName, String roles, 
																String sessionId, String ipAddr, int result) {
		Transaction tx = null;
		AppDBLogger sessionLog = null;
		String msgLog;
		
		switch (result) {
			case AppUserCtrl.LOGIN_SUCCESS: { 
				AppGroup mainGrp = 
						getPrimaryActiveGroup ((AppUser)theSess.get(AppUser.class, userId));
				
				msgLog = "User '"+userName+"' logged in with roles '"+roles+"'";
				if (mainGrp != null)
					msgLog += " and for primary group '"+mainGrp.getName()+"'";
				break;
			}
			case AppUserCtrl.LOGIN_FAIL:
				msgLog = "Fail to log in for user '"+
							userName+"': mismatching username:password";
				break;
				
			case AppUserCtrl.LOGIN_CONCURRENT:
				msgLog = "User '"+userName+"' ("+userId+") tried to access from "+
								ipAddr+" while already logged in";
				break;
				
			default: msgLog = "Attempt to log in audited";
				break;
		}
		
		try {
			tx = theSess.beginTransaction();
			sessionLog = new AppDBLogger ();
			sessionLog.setUserId(userId);
			sessionLog.setSessionId(sessionId);
			sessionLog.setMessage(msgLog);
			sessionLog.setLastIp(ipAddr);
			theSess.save(sessionLog);
			tx.commit();
			
			return true;
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			LogFile.error("Fail to log user session init:\t");
			LogFile.error("userId="+userId+"; sessionId="+sessionId);
			LogFile.error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
			return false;
		}
	}
	
	
	

//OjO con este method	
	protected void finalize () {
    if (theSess != null) {
    	if (theSess.isOpen()) {}
        // theSess.close();
    }
	}
	
	
}
