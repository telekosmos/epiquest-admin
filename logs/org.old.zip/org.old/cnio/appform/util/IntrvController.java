package org.cnio.appform.util;

import static org.hibernate.criterion.Restrictions.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

import org.apache.commons.lang.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.AnnotatedClassType;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.*;
import org.hibernate.SQLQuery;

import org.cnio.appform.entity.*;

/**
 * This class contains methods for duplicating an interview for another group
 * @author willy
 *
 */
public class IntrvController {

	private Session hibSes;
	
	
	public IntrvController (Session aSession) {
		hibSes = aSession;
	}
	
	
	
/**
 * Replicate the interview with id intrvId for the group of users represented 
 * by grp 
 * @param intrvId, the source interview id
 * @param grp, the target group 
 * @return, a new interview 
 */	
	public Interview replicateIntrv (Integer intrvId, AppGroup grp) {
		
		Interview intrvAux = (Interview)hibSes.get(Interview.class, intrvId), 
							intrvBis = null;
		Transaction tx = null;
		try {
			tx = hibSes.beginTransaction();
			intrvBis = (Interview)intrvAux.clone();
			Integer intId = (Integer)hibSes.save(intrvBis);
System.out.println("Interview "+intrvBis.getName()+" cloned with id: "+intId);

			RelIntrvGroup rig = new RelIntrvGroup (grp, intrvBis);
			Integer rigId = (Integer)hibSes.save(rig);
System.out.println("Interview assigned to group "+grp.getName());			
// Now, the answer items has to be assigned to every question
// At this point, the relationship between the cloned questions and the
// cloned answeritems doesnt exist, because the relationship is between the
// cloned questions and the original/old answeritems
			List<AbstractItem> items = getItemsFromIntrv (intrvBis);
			List<AnswerItem> ansItList = intrvBis.getAnswerItems();
			for (Iterator<AbstractItem> itemIt = items.iterator(); itemIt.hasNext();) {
				AbstractItem theItem = itemIt.next();
				
				if (theItem instanceof Text)
					continue;
				
				else { // it should be a Question
					List<QuestionsAnsItems> lQai = ((Question)theItem).getQuestionAnsItems();
					for (Iterator<QuestionsAnsItems> itQai = lQai.iterator(); itQai.hasNext();) {
						QuestionsAnsItems qai = itQai.next();
						AnswerItem ai = qai.getTheAnswerItem();
// The ai is the old answerItem and now we have to get the cloned answeritem
// and substitute the original/old with the new one
// In order to do this, the cloned answeritem has to be got from the list of 
// cloned answeritems with the cloned interview as owner
						int index = ansItList.indexOf(ai);
						qai.setTheAnswerItem(ansItList.get(index));
					}
				}
				
			}
			
			tx.commit();
//System.out.println("the new intrvId: "+intId);
		}
		catch (Exception ex) {
			if (tx != null)
				tx.rollback();
			
//			ex.printStackTrace();
			return null;
		}
		return intrvBis;
	}
	
	
	
	
/**
 * Replicate the interview intrvAux for the group of users represented 
 * by grp 
 * @param intrvId, the source interview id
 * @param grp, the target group 
 * @return, a new interview 
 */	
	public Interview replicateIntrv (Interview intrvAux, AppGroup grp) {
		
		Interview intrvBis = null;
		Transaction tx = null;
		try {
			tx = hibSes.beginTransaction();
			intrvBis = (Interview)intrvAux.clone();
			Integer intId = (Integer)hibSes.save(intrvBis);
// System.out.println("IntrvController.replicateIntrv: Interview "+intrvBis.getName()+" cloned with id: "+intId);

			RelIntrvGroup rig = new RelIntrvGroup (grp, intrvBis);
			Integer rigId = (Integer)hibSes.save(rig);
// System.out.println("IntrvController.replicateIntrv: Interview assigned to group "+grp.getName());			
// Now, the answer items has to be assigned to every question
// At this point, the relationship between the cloned questions and the
// cloned answeritems doesnt exist, because the relationship is between the
// cloned questions and the original/old answeritems
			List<AbstractItem> items = getItemsFromIntrv (intrvBis);
			List<AnswerItem> ansItList = intrvBis.getAnswerItems();
			for (Iterator<AbstractItem> itemIt = items.iterator(); itemIt.hasNext();) {
				AbstractItem theItem = itemIt.next();
				
				if (theItem instanceof Text)
					continue;
				
				else { // it should be a Question
					List<QuestionsAnsItems> lQai = ((Question)theItem).getQuestionAnsItems();
					for (Iterator<QuestionsAnsItems> itQai = lQai.iterator(); itQai.hasNext();) {
						QuestionsAnsItems qai = itQai.next();
						AnswerItem ai = qai.getTheAnswerItem();
// The ai is the old answerItem and now we have to get the cloned answeritem
// and substitute the original/old with the new one
// In order to do this, the cloned answeritem has to be got from the list of 
// cloned answeritems with the cloned interview as owner
						int index = ansItList.indexOf(ai);
						qai.setTheAnswerItem(ansItList.get(index));
					}
				}
				
			}
			
			tx.commit();
//System.out.println("the new intrvId: "+intId);
		}
		catch (Exception ex) {
			if (tx != null)
				tx.rollback();
			
				ex.printStackTrace();
			return null;
		}
		return intrvBis;
	}	
	
	
	
/**
 * Find out whether or not the interview represented by intrvId is cloned
 * @param intrvId
 * @return true if the interview is a clone of another; false if it is 
 * an original interview
 */	
	public Boolean isClon (Integer intrvId) {
		Transaction tx = null;
		Boolean cloned = true;
		try {
			tx = hibSes.beginTransaction();
			Interview intrv = (Interview)hibSes.get(Interview.class, intrvId);
			
			cloned = (intrv.getSourceIntrv() == null)? false: true;
			return cloned;
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			return null;
		}
	}

	
	
	
/**
 * Gets all items from all sections from the interview represented by intrv
 * @param intrv, the interview whose elements want to be retrieved
 * @return, a list with the items
 */	
	private List<AbstractItem> getItemsFromIntrv (Interview intrv) {
		List<AbstractItem> aux = new ArrayList<AbstractItem>();
		List<Section> sections = intrv.getSections();
		
		for (Iterator<Section> itSec = sections.iterator(); itSec.hasNext();) {
			Section sec = itSec.next();
			aux.addAll(sec.getItems());
		}
		
		return aux;
	}
	


/**
 * Add a list of Interviews to the Project proj
 * @param session
 * @param intrv
 * @param sections
 * @return
 */	
	public boolean addIntr2Proj (Project proj, List<Interview> intrvs) {
		
		Transaction tx = hibSes.getTransaction();
		tx = (!tx.isActive())? hibSes.beginTransaction(): tx;
		try {
			
			Iterator<Interview> itIntr = intrvs.iterator();
			while (itIntr.hasNext()) {
				Interview oneIntr = itIntr.next();
				oneIntr.setProject(proj);
			}
			
			tx.commit();	
			return true;
		} 
		catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
				e.printStackTrace();
			}
			return false;
		}
	}




/**
 * Creates a new interview based on name and description
 * @param hibSess
 * @param name, a String representing the name of the section
 * @param desc, a String representing some description
 * @return
 */	
	public boolean createInterview (String name, String desc) {
		Transaction tx = null;
		try {
			tx = hibSes.getTransaction();
			tx = (!tx.isActive())? hibSes.beginTransaction(): tx;
			
			Interview intrv = new Interview (name, desc);
			hibSes.save(intrv);
			tx.commit();
			
			return true;
		}
		catch (HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			
			hibEx.printStackTrace();
			return false;
		}
	}




/**
 * This method gets the list of interviews based on the current project and the
 * main group which the user belongs to. This is necessary because the interviews
 * belong to a entire group of users, which is the COUNTRY group in the case of
 * Pangenes development
 * In the case of a user with role 'admin', all interviews have to be returned
 * @param hibSes
 * @param prjId, the id of the project
 * @param usrId, the id of the user, necessary to get the main group
 * @return a Interview list or null
 */		
	public List<Interview> getIntrv4Usr (Integer prjId, Integer usrId) {
		AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
		AppUser user = (AppUser)hibSes.get(AppUser.class, usrId);
		Project prj = (Project)hibSes.get(Project.class, prjId);
		List<Interview> lIntrv = null;
		
		if (user == null)
			return null;
		
		else {
			Transaction tx = null;
			List<AppGroup> userGroups = usrCtrl.getGroups(user), auxGroups;
			AppGroup activeGroup = usrCtrl.getPrimaryActiveGroup(user);
/*			
String hqlIntr = "from RelIntrvGroup rig where rig.appgroup=:group and " +
"intrv.parentPrj=:prj";
*/
			String hqlAdm = "from Interview";
			String hqlGrpTmpl = "from AppGroup g where g in (:groups) and"+
										" g.type.name='"+HibernateUtil.MAIN_GROUPTYPE+"'";
			String hqlIntrBis = "from Interview i join i.relIntrvGrps rig where" +
					" rig.appgroup=:group and i.parentPrj=:prj";
			
			try {
				tx = hibSes.beginTransaction();
				if (user.isAdmin()) {
					Query qry = hibSes.createQuery(hqlAdm);
					lIntrv = qry.list();
					tx.commit();
					
					return lIntrv;
				}
/*				
				Query qGrp = hibSes.createQuery(hqlGrpTmpl);
				qGrp.setParameterList("groups", userGroups);
				auxGroups = qGrp.list();
*/
				Query qIntr = hibSes.createQuery(hqlIntrBis);
//				qIntr.setEntity("group", auxGroups.get(0));
				qIntr.setEntity("group", activeGroup);
				qIntr.setEntity("prj", prj);
				List<Object[]>lAux = qIntr.list();
				
				Iterator<Object[]> itAux = lAux.iterator();
				lIntrv = new ArrayList<Interview>();
				while (itAux.hasNext()) {
					Object[] pair = (Object[])itAux.next();
					lIntrv.add((Interview)pair[0]);
				}
				
				tx.commit();
			}
			catch (HibernateException hibEx) {
				if (tx != null)
					tx.rollback();
				
				hibEx.printStackTrace();
			}
		}
		
		return lIntrv;
	}




/**
 * Get the list of interviews for the project identified with prjId and for an
 * owner identified with his/her system id. The list of interviews is the list of
 * interviews for all users in that group (actually, the country)
 * @param session
 * @param prjId
 * @param userId
 * @return
 */	
	public List<Interview> getIntr4Proj (Integer prjId, Integer userId) {
		AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
		AppUser user = (AppUser)hibSes.get(AppUser.class, userId);
		Project prj = (Project)hibSes.get(Project.class, prjId);
		
		if (user == null)
			return null;
		
		else {
/*			List<AppUser> lUsr = usrCtrl.getUserPartners(user);
			int numUsrs = lUsr.size(), cont=1;
			
			String sql = "select i.* from project p, interview i " +
					"where p.idprj="+prjId+" and (";
			
			for (AppUser usr: lUsr) {
				sql += "i.codusr="+usr.getId();
				if (cont == numUsrs)
					sql += ")";
				else
					sql += " or ";
				
				cont++;
			}
			
			sql += " and i.codprj=p.idprj";
*/			
//	System.out.println(sql);
			Transaction tx = null;
			List<AppGroup> userGrps = usrCtrl.getGroups(user);
			String hqlCountry = "from AppGroup g where g in :groups and g.type.name='COUNTRY'";
			
			
			String hql = "from Interview i where parentPrj=:prj";
			List<Interview> intCol;
//			intCol = session.createSQLQuery(sql).addEntity(Interview.class).list();
			Query qHql = hibSes.createQuery(hql).setEntity("prj", prj); 
			intCol = qHql.list();
		
			return intCol;
		}
		
	}



/**
 * Gets the basic (and neutral, without belonging any interview templ) answer 
 * types. They are 3 basic (label, number and decimal) and one enum type (yes/no)
 * @return a list of the basic answer items
 */
	private List<AnswerItem> defaultTypes () {
		String hqlStr = "from AnswerItem a where a.id in ("+
		HibController.TYPE_LABEL_ID+","+HibController.TYPE_NUMBER_ID+","+
		HibController.TYPE_DECIMAL_ID+","+HibController.TYPE_ENUM_YES+")";
//			hqlStr += "or lower(a.name) like '%yes%'";
		
		Transaction tx = null;
		List<AnswerItem> ansItems = null;
		try {
			tx = hibSes.beginTransaction();
			Query qry = hibSes.createQuery(hqlStr);
			
			ansItems = qry.list();
			
			return ansItems;
		}
		catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			
			return null;
		}
		
	}
	

/**
 * Creates a new interview based on name and description. Besides, as it is part
 * of every interview, the Introduction section is added by default
 * usrId will have to be removed because the users are assigned to projects, not
 * to interviews
 * @param hibSess
 * @param name, a String representing the name of the section
 * @param desc, a String representing some description
 * @param parentPrj, the identifier of the parent project
 * @return
 */	
	public int createInterview (String name,String desc, Integer parentPrj,
								Integer usrId) {
		Transaction tx = null;
		Integer intrId;
		boolean res = true;
LogFile.info("IntrvController.createInterview ()!!!");
// Get user from usrId and main group for user
		AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
		AppUser theUsr = (AppUser)hibSes.get(AppUser.class, usrId);
		AppGroup mainGroup = usrCtrl.getPrimaryGroup(theUsr);
		
		try {
			tx = hibSes.getTransaction();
// System.out.println("tx.active: "+tx.isActive());			
			tx = (!tx.isActive())? hibSes.beginTransaction(): tx;
			
			Interview intrv = new Interview (name, desc);
			intrv.setUsrOwner(theUsr);
			intrId = (Integer)hibSes.save(intrv);

// Assign the user main group to this interview in order the other users in the
// group can access it.				
			RelIntrvGroup rig = new RelIntrvGroup (mainGroup, intrv);
			hibSes.save(rig);
			
			
			List<AnswerItem> lItems = defaultTypes ();
			for (Iterator<AnswerItem> itItems=lItems.iterator(); itItems.hasNext(); ) {
				AnswerItem ai = itItems.next(), clonedAi;
				clonedAi = (AnswerItem)ai.clone();
				clonedAi.setIntrvOwner(intrv);
				
				Long clonedId = (Long)hibSes.save(clonedAi);
			}
			
// System.out.println("tx.active: "+tx.isActive());			
			String hqlQry = "from AnswerItem ai where upper(ai.name)=upper('"+
							HibController.TYPE_LABEL +	"') and ai.intrvOwner=:owner";
			AnswerItem ai; /*
			Criteria ct = hibSes.createCriteria(AnswerItem.class).
			 										add(like("name", "label"+"%").ignoreCase());
			 */
			Query hql = hibSes.createQuery(hqlQry);
			hql.setEntity("owner", intrv);
			Collection<AnswerItem> colItems = hql.list();
			
			ai = (colItems != null)? colItems.iterator().next(): null;
			if (ai == null) {
				tx.rollback();
				return -1;
			}
			else {
				Section intro = new Section ("Introducci�n", "");
				intro.setSectionOrder(new Integer (1));
				intro.setInterview(intrv);
				hibSes.save(intro);
// Box for patient code				
				Question qPatCode = new Question ("C�digo de paciente:");
				qPatCode.setParentSec(intro);
				qPatCode.setItemOrder(new Long (1));
				qPatCode.setMandatory(1);
				qPatCode.setHighlight(0);
				hibSes.save(qPatCode);
			
				QuestionsAnsItems qas = new QuestionsAnsItems (qPatCode, ai);
				qas.setAnswerOrder(new Long(1));
				hibSes.save(qas);

			}
			
			tx.commit();
			
			List<Interview> l = new ArrayList<Interview>();
			Interview intr = (Interview)hibSes.get(Interview.class, intrId);
			Project prj = (Project)hibSes.get(Project.class, parentPrj);
			l.add(intr);
			res = res && addIntr2Proj(prj, l);
			
			
	// if the creation of the intro was ok, then we commit the transaction, other
	// wise it is considered the interview can not be created 
			/*
			if (res)
				tx.commit();
			else
				tx.rollback();
			*/
			return intrId;
		}
		catch (HibernateException hibEx) {
			if (tx != null)
				tx.rollback();
			
			LogFile.error("Fail create interview:\t");
			LogFile.error(hibEx.getLocalizedMessage());
			StackTraceElement[] stack = hibEx.getStackTrace();
			LogFile.logStackTrace(stack);
hibEx.printStackTrace();
			
			return -1;
		}
		catch (CloneNotSupportedException ex) {
			if (tx != null)
				tx.rollback();
			
			LogFile.error("Fail to log interview creation:\t");
			LogFile.error(ex.getLocalizedMessage());
			StackTraceElement[] stack = ex.getStackTrace();
			LogFile.logStackTrace(stack);
			
			return -1;
		}
		
	}




/**
 * Delete an interview based on an id
 * @param session, the hibernate session
 * @param secId, the id of the section which is gonna be deleted
 * @return true on sucessfully completion; otherwise false
 */	
	public boolean removeInterview (Integer intrId) {
		Transaction tx = hibSes.getTransaction();
		tx = (!tx.isActive())? hibSes.beginTransaction(): tx;
		try {
			Interview theIntr = (Interview)hibSes.get(Interview.class, intrId);
			
			hibSes.delete(theIntr);
			tx.commit();	
			return true;
		} 
		catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
				e.printStackTrace();
			}
			return false;
		}
	}
	
	
	
	
/**
 * This method clones the answer-items belonging to one interview or, if the 
 * source interview is null, all answer-items and it relates them with the
 * target interview
 * @param src, the source interview for the source answer-items (it can be null)
 * @param dest, the target interview where the answer-items are gonna be 
 * cloned to
 * @return true on successful termination; false on error
 */		
	public boolean cloneAnswerItems (Interview src, Interview dest) {
		List<AnswerItem> lAnsIt;
		Transaction tx;
// HibernateUtil.getAnswerItems has a inner transaction		
		if (src == null) 
			lAnsIt = HibernateUtil.getAnswerItems(hibSes, src);
		else
			lAnsIt = src.getAnswerItems();
		
		
		try {
			tx = hibSes.beginTransaction();
			
			for (Iterator<AnswerItem> aiIt = lAnsIt.iterator(); aiIt.hasNext();) {
				AnswerItem ai = aiIt.next(), newAi;
				
				if (ai instanceof AnswerType) 
					newAi = (AnswerItem)((AnswerType)ai).clone();
					
				else  // an EnumType
					newAi = (AnswerItem)((EnumType)ai).clone();
				
				Long newAiId = (Long)hibSes.save(newAi);
				dest.setAnswerItem(newAi);
			}
			hibSes.flush();
			
			tx.commit();
		}
		catch (CloneNotSupportedException ex) {
			ex.printStackTrace();
			return false;
		}
		
		return true;
	}
	

	protected void finalize () {
		if (hibSes != null)
			if (hibSes.isOpen())
				hibSes.close();
	}
}