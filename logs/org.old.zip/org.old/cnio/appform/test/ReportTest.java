package org.cnio.appform.test;

import java.io.*;
import org.cnio.appform.entity.*;

import org.cnio.appform.util.HibernateUtil;
import org.cnio.appform.util.HibController;
import org.cnio.appform.util.IntrvController;
import org.cnio.appform.util.LogFile;
import org.cnio.appform.util.AppUserCtrl;
import org.cnio.appform.util.IntrvFormCtrl;
import org.cnio.appform.util.RenderEng;
import org.cnio.appform.util.ReportUtil;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import static org.hibernate.criterion.Restrictions.*;
import org.hibernate.Query;
import org.hibernate.SQLQuery;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

import java.io.UnsupportedEncodingException;
import java.net.*;

import org.apache.commons.lang.StringEscapeUtils;

public class ReportTest {

	Session hibSess;
	
	public ReportTest () {
		SessionFactory sf = HibernateUtil.getSessionFactory();
		hibSess = sf.openSession();
	}
	
	public Session getHibSes () {
		return hibSess;
	}
	
	
	public Session getCurrentHibSes () {
		hibSess = HibernateUtil.getSessionFactory().getCurrentSession();
		
		return hibSess;
	}
	
	
	public Session getCurrentSession () {
		return HibernateUtil.getSessionFactory().getCurrentSession();
	}
	
	
	public Session openSession () {
		hibSess = HibernateUtil.getSessionFactory().openSession();
		
		return hibSess;
	}
	
	
	public void closeHibSes () {
		hibSess.close();
	}
	
	
	public static void main (String[] args) {
		
		ReportTest report = new ReportTest();
		Interview myIntrv = (Interview)report.getHibSes().get(Interview.class, 50);
		ReportUtil repUtil = new ReportUtil (report.getHibSes());
		List<Object[]> questions = repUtil.getQuestionCodes(myIntrv);
		
		if (questions != null) {
			int contQs = 0;
			for (Iterator<Object[]> itObj = questions.iterator(); itObj.hasNext();) {
				Object[] item = itObj.next();
				contQs++;
				System.out.print(contQs+".- ");
				for (int i=0; i<item.length-1; i++) {
					
					String msg;
					switch (i) {
						case 0: msg = "ID: "; break;
						case 1: msg = "CodQ: "; break;
						case 2: msg = "Subs: "; break;
						case 3: msg = "Sec: "; break;
						default: msg = "";
					}
					
					msg += item[i]+", ";
					System.out.print(msg);
				}
				System.out.println();
			}
		}
		else
			System.out.println("No questions or fail");
		
		report.closeHibSes();
System.out.println("\nFinish!!");
	}
	
}