/**
 * 
 */
package org.cnio.appform.servlet.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import java.security.Principal;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cnio.appform.entity.AppUser;
import org.cnio.appform.entity.Role;
import org.cnio.appform.util.AppUserCtrl;
import org.cnio.appform.util.HibernateUtil;
import org.hibernate.Session;

/**
 * @author bioinfo
 *
 */
public class AuthenticationFilter implements Filter {

	private FilterConfig cfg;
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse resp,
												FilterChain chain) throws IOException, ServletException {

		if (req instanceof HttpServletRequest) {
			HttpServletRequest httpReq = (HttpServletRequest) req;
			String username = httpReq.getRemoteUser();
			Principal myPpal = httpReq.getUserPrincipal();
			HttpSession session = httpReq.getSession(false);
			Integer loggedIn = 0;
			
			if (session != null) {
				loggedIn = (Integer)session.getAttribute("logged");
				loggedIn = (loggedIn == null)? 0: 1;
			}
			
			if (username != null && loggedIn == 0) { // authenticated!!!! -> set session vars
System.out.println("doFilter(): username: "+username+", myPpal: "+myPpal.getName());
				
//				PrintWriter pw = resp.getWriter();
//				pw.println("session: " + session.getId());
				List<Role> roles = null;
				AppUserCtrl userCtrl = null;
				AppUser appUsr = null;
				Session hibSes = null;

				hibSes = HibernateUtil.getSessionFactory().openSession();

				userCtrl = new AppUserCtrl(hibSes);
				appUsr = userCtrl.getUser(username);
				appUsr.setLoggedIn(1);
				roles = userCtrl.getRoleFromUser(appUsr);

				String strRoles = "";
				for (Role r : roles) {
					strRoles += r.getName() + ",";
				}
				if (strRoles.length() > 0)
					strRoles = strRoles.substring(0, strRoles.length() - 1);

				// checking if the user is allowed to act as admin
				if (strRoles.length() == 0 || strRoles.indexOf("admin") == -1) {
					// session.invalidate();
					if (resp instanceof HttpServletResponse) {
						HttpServletResponse httpRes = (HttpServletResponse)resp;
						httpRes.sendRedirect("../logout.jsp?adm=1");
						
					}
				}
				else {
					if (session != null) {
						session.setAttribute("usrid", appUsr.getId());
						session.setAttribute("user", username);
						session.setAttribute("roles", strRoles);
						session.setAttribute("logged", 1);
					} 
					else
						System.out.println ("session is null in Auth..Filter");
				}
			} // user != null
		}
		
		chain.doFilter(req, resp);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		cfg = arg0;
	}

}
