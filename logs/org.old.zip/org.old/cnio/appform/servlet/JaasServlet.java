package org.cnio.appform.servlet;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cnio.appform.jaas.*;
import org.cnio.appform.entity.Role;
import org.cnio.appform.entity.AppUser;
import org.cnio.appform.util.HibernateUtil;
import org.cnio.appform.util.AppUserCtrl;

import org.hibernate.Session;
import org.hibernate.HibernateException;

import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.Callback;

import java.util.List;
import java.util.Iterator;

import java.io.PrintWriter;

import org.cnio.appform.jaas.AppJaasConfiguration;


/**
 * Servlet implementation class for Servlet: JaasServlet
 *
 */
 public class JaasServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
   private static final String JAAS_CONFIG_NAME = "appform";
   
//   private String jaasConfigLoc;
   
  /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public JaasServlet() {
		super();
//		jaasConfigLoc = getServletContext().getInitParameter("jaas.config");
	}   	
	
	
	
	public void init (ServletConfig config) throws ServletException {
System.out.println("JaasServlet.init(...) - initializing configuration for jaas");
		super.init(config);
//		jaasConfigLoc = getServletContext().getInitParameter("jaas.config");
		String realPath = config.getServletContext().getRealPath("/");
		AppJaasConfiguration.init(realPath);
	}
	
	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
						throws ServletException, IOException {
System.out.println("in doGet()"+request.getParameter("j_username"));
		String username = request.getParameter("j_username");
		String passwd = request.getParameter("j_password");
		
		
		CallbackHandler cbh = new AppPassiveCallbackHandler (username, passwd);
		Subject theUsr;
		try {
			LoginContext lc = new LoginContext ("admtool", cbh);
			lc.login();
			
			theUsr = lc.getSubject();
// System.out.println("doGet() has retrieved person: "+person.toString());
		}
		catch (LoginException ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		
// now we initialize the application session vars
		HttpSession session = request.getSession(false);
PrintWriter pw = response.getWriter();
pw.println("session: "+session.getId());
		List<Role> roles = null;
		AppUserCtrl userCtrl = null;
		AppUser appUsr = null;
		Session hibSes = null;
		
		if (username == null || username.length() == 0)
			response.sendRedirect("../logout.jsp?adm=1");

		else {
			hibSes = HibernateUtil.getSessionFactory().openSession();

			userCtrl = new AppUserCtrl(hibSes);
			appUsr = userCtrl.getUser(username);
			appUsr.setLoggedIn(1);
			roles = userCtrl.getRoleFromUser(appUsr);

			String strRoles = "";
			for (Role r : roles) {
				strRoles += r.getName() + ",";
			}
			if (strRoles.length() > 0)
				strRoles = strRoles.substring(0, strRoles.length() - 1);

			// checking if the user is allowed to act as admin
			if (strRoles.length() == 0 || strRoles.indexOf("admin") == -1) {
				//	session.invalidate();
				response.sendRedirect("../logout.jsp?adm=1");
			} 
			else {
				if (session != null) {
					session.setAttribute("usrid", appUsr.getId());
					session.setAttribute("user", username);
					session.setAttribute("roles", strRoles);
				}
				else
				 this.getServletContext().log("session is null in JaasServlet");
			}
		} // else
		
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}   	  	    
}