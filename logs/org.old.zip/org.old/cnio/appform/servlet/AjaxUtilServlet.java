package org.cnio.appform.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cnio.appform.entity.*;
import org.cnio.appform.util.AppUserCtrl;
import org.cnio.appform.util.HibernateUtil;

import org.hibernate.Session;

import java.util.List;
import java.util.Iterator;
import java.io.PrintWriter;

/**
 * Servlet implementation class for Servlet: AjaxUtil
 * This is a servlet which is used as server communication for the admintool
 *
 */
 public class AjaxUtilServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   static final String PRJS = "prj";
   static final String GRPS = "grp";
   static final String ROLES = "rol";
   
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public AjaxUtilServlet() {
		super();
	}   	
	
/* 
 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String what = request.getParameter("what");
		String usrId = request.getParameter("usrid");
		String jsonResp = "";
		List<AppGroup> groups = null;
		List<Project> prjs = null;
		List<Role> roles = null;
		boolean nothing = false;
		
		PrintWriter out = response.getWriter();
		Session hibSes = HibernateUtil.getSessionFactory().openSession();
		AppUser theUsr = null;
		if (usrId != null)
			theUsr = (AppUser)hibSes.get(AppUser.class, Integer.parseInt(usrId));
		
		AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
		what = (what==null)? "": what;
		if (what.equals(AjaxUtilServlet.GRPS)) {
			groups = (theUsr == null)? usrCtrl.getAllGroups(): usrCtrl.getGroups(theUsr);
			jsonResp = "{\"groups\":[";
			for (AppGroup grp: groups) 
				jsonResp += "{\"name\":\""+grp.getName()+"\",\"id\":"+grp.getId()+"},";
		}
		else if (what.equals(AjaxUtilServlet.PRJS)) {
			prjs = (theUsr == null)? usrCtrl.getAllProjects(): usrCtrl.getProjects(theUsr);
			jsonResp = "{\"prjs\":[";
			for (Project prj: prjs) 
				jsonResp += "{\"name\":\""+prj.getName()+"\",\"id\":"+prj.getId()+"},";
		}
		else if (what.equals(AjaxUtilServlet.ROLES)) {
			roles = (theUsr == null)? usrCtrl.getAllRoles(): usrCtrl.getRoleFromUser(theUsr);
			jsonResp = "{\"roles\":[";
			for (Role role: roles) 
				jsonResp += "{\"name\":\""+role.getName()+"\",\"id\":"+role.getId()+"},";
		}
		else {
			nothing = true;
			jsonResp = "{\"msg\":\"Nothing to retrieve\"}";
			out.print(getServletInfo());
		}
		
		if (!nothing) {
			jsonResp = (jsonResp.length()==0)? jsonResp: 
									jsonResp.substring(0, jsonResp.length()-1);
			jsonResp += "]}";
		}
		
		
		out.print (jsonResp);
	}  	
	
/* (non-Java-doc)
 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}   	  	
	
/* (non-Javadoc)
 * @see javax.servlet.Servlet#getServletInfo()
 */
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return super.getServletInfo();
	}     
}