package org.cnio.appform.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cnio.appform.entity.*;
import org.cnio.appform.util.AppUserCtrl;
import org.cnio.appform.util.HibernateUtil;
import org.cnio.appform.util.LogFile;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.HibernateException;

import java.util.List;
import java.util.Iterator;
import java.io.PrintWriter;

/**
 * This servlet is the response servlet for requests to active a groups if 
 * the user belongs to several groups, primary or secondary ones
 * 
 * The doPost method will be operating here as the database has to be changed.
 * The servlet gets 2 parameters: userId and selected groupId, enough to
 * access to the RelGrpAppuser entity class and update the active field.
 * 
 * The type of group is not necessary as the changing process is the same
 */
 public class MngGroupsServlet extends javax.servlet.http.HttpServlet 
 															implements javax.servlet.Servlet {

    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public MngGroupsServlet() {
		super();
	}   	
	
	
	public void init () {
		
	}

	
/**
 *  
 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String json = "{\"res\":0,\"msg\":\"GET operations are not allowed with" +
				" this servlet\"}";
		
		PrintWriter out = response.getWriter();
		out.print (json);
		
	}  	
	
	
	
	
/**
 * 
 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
	protected void doPost (HttpServletRequest request, HttpServletResponse response) 
						throws ServletException, IOException {
		
		Integer usrId = (Integer)request.getSession().getAttribute("usrid");
		Integer grpId = Integer.parseInt (request.getParameter("grpid"));
		String intrvId = request.getParameter("intrvid");
		String json = "{\"res\":0,\"msg\":\"at least, this is a json response\"}", 
								groupName = "groupName";
		
		HttpSession mySes = request.getSession();
		String msgLog;
		
		Session hibSes = HibernateUtil.getSessionFactory().openSession();
		
		AppUserCtrl usrCtrl = new AppUserCtrl (hibSes);
		AppUser user = (AppUser)hibSes.get(AppUser.class, usrId);
		AppGroup grp = (AppGroup)hibSes.get(AppGroup.class, grpId);
		groupName = grp.getName();
		String grpTypeName = grp.getType().getName();
		
		boolean success = usrCtrl.setActiveGroup(user, grp, 1);
//		boolean success = false;
		
		if (success) {
			json = "{\"res\":1,\"msg\":\"New active group is '"+groupName+"'\",";
			json += "\"intrv\":"+intrvId+"}";
			if (grpTypeName.equalsIgnoreCase(HibernateUtil.MAIN_GROUPTYPE)) {
				mySes.setAttribute("primaryGrpId", grpId);
				mySes.setAttribute("primaryGrpName", groupName);
				
				msgLog = "User '"+user.getUsername()+"' has selected '"+groupName+
							"' as primary active group";
			}
			else {
				mySes.setAttribute("secondaryGrpId", grpId);
				mySes.setAttribute("secondaryGrpName", groupName);
				
				msgLog = "User '"+user.getUsername()+"' has selected '"+groupName+
				"' as secondary active group";
			}
			
// This is to audit the group selection
			Transaction tx = null;
			try {
				tx = hibSes.beginTransaction();
				
				AppDBLogger sessionLog = new AppDBLogger ();
				sessionLog.setUserId(usrId);
				sessionLog.setSessionId(mySes.getId());
				sessionLog.setMessage(msgLog);
				sessionLog.setLastIp(request.getRemoteAddr());
				hibSes.save(sessionLog);
				
				tx.commit();
			}
			catch (HibernateException ex) {
				if (tx != null)
					tx.rollback();
				
				LogFile.error("Fail to log user group selection:\t");
				LogFile.error("userId="+usrId+"; sessionId="+mySes.getId());
				LogFile.error(ex.getLocalizedMessage());
				StackTraceElement[] stack = ex.getStackTrace();
				LogFile.logStackTrace(stack);
			}
			finally {
				hibSes.close();
			}
		}
		else {
			json = "{\"res\":0,\"msg\":\"New group activation could not be performed" +
					". Contact with <a href=\\\"mailto:" +AppUserCtrl.ADM_MAIL+ "\\\">" +
					"administrator</a> to report and solve this issue\"}";
		}
		
		PrintWriter out = response.getWriter();
		out.print(json);
	}   	  	
	
	
	
/* (non-Javadoc)
 * @see javax.servlet.Servlet#getServletInfo()
 */
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return super.getServletInfo();
	}     
}